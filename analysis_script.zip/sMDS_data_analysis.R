#### Load Packages ####
#for general functions 
library(ggplot2)
library(broom)
library(car)
library(caret)
library(plyr)
library(psych)
library(tidyverse)
library(dplyr)
library(reshape2)
library(qwraps2) 
library(devtools)
library(tidytext)
library(rstatix)
library(fmsb)
library(rcompanion)
library(Rmisc)
library(purrr)
#for sample matching 
library(MatchIt)
library(optmatch)
#for plotting
library(cowplot)
library(dotwhisker)
library(GGally)
library(ggeffects)
library(gridExtra)
library(ggpubr)
library(jtools)
library(sjPlot)
library(effects)
library(latticeExtra)
library(corrplot)
library(RColorBrewer)
library(jcolors)
library(plotly)
library(gplots)
library(ggthemes)
library(ggstance)
library(dplyr)
library(stats)
library(ez)
#remotes::install_github("ricardo-bion/ggradar")
library(networkD3)
library(wesanderson)
#for K means clustering and analyses 
library(kml)
library(kml3d)
library(lme4)
library(DHARMa)
library(broom.mixed)
library(jtools)
#load for models

library(lme4)
library(emmeans)
library(afex)
library(nloptr)
library(optimx)
library(performance)
#for model convergence issues 
library(optimx)
library(parallel)
library(minqa) 
#for MDS
library(magrittr)
library(dplyr)
library(ggpubr)
library(MASS)
library(factoextra)
library(NbClust)
#strategy dataset-qualitative responses -----
strategy
colnames(strategy)[1] <- "ID"
colnames(strategy)[2] <- "response"
# Load libraries
library(tm)
library(wordcloud)
library(wordcloud2)
library(ggplot2)
library(dplyr)
strategy_45_2 <- subset(strategy, select = response)
strategy_45_2 <- unlist(strategy_45_2)
# Create a text corpus
text <- strategy_45_2
docs <- Corpus(VectorSource(text))
# Clean the text data
docs <- docs %>%
  tm_map(removeNumbers) %>%
  tm_map(removePunctuation) %>%
  tm_map(stripWhitespace)
docs <- tm_map(docs, content_transformer(tolower))
docs <- tm_map(docs, removeWords, stopwords("english"))
# Create a term-document matrix
dtm <- TermDocumentMatrix(docs)
matrix <- as.matrix(dtm)
words <- sort(rowSums(matrix), decreasing = TRUE)
df <- data.frame(word = names(words), freq = words, stringsAsFactors = FALSE)
print(str(df))  # Should be a data.frame
print(head(df)) # Check first few rows

set.seed(1234)# Set seed for reproducibility
my_colors <- c("indianred", "aquamarine4", "olivedrab", "hotpink4", "orange2", "darkturquoise")
wordcloud(words = df$word, freq = df$freq, min.freq = 1,          
          max.words = 200, random.order = FALSE, rot.per = 0.35,            
          colors = my_colors)
png("wordcloud.png", width = 300, height = 300)  # Adjust size if needed
# Extract top 10 words
df_top10 <- df[1:10, ]
df_top10$colour_bar <- rep(c('A', 'B'), length.out = nrow(df_top10))
qual_bar <- ggplot(df_top10, aes(x = reorder(word, - freq), y = freq)) +
  geom_bar(stat = 'identity', fill = 'skyblue4', colour = 'black') +
  ggtitle("Top 10 Words in Responses") +
  theme_classic() +
  labs(x = 'Top 10 words', y = 'Frequency (n)') +
  theme(legend.position = 'none',
        plot.background = element_rect(fill = "white"),
        legend.title = element_blank(),
        legend.text = element_text(size = 12),
        axis.title = element_text(size = 14),
        axis.text = element_text(size = 12),
        strip.text = element_text(size = 14))
print(qual_bar)
ggsave('10_words.png', qual_bar, width = 8, height = 6, dpi = 300)
qualitative_combined <- ggarrange(qual_bar,qual_bar, ncol =2, nrow=1)

#SR analysis -----
setwd("C:\\Users\\marti\\OneDrive - TCDUD.onmicrosoft.com\\Documents\\Studies\\Data\\MOC_mov\\sMDS\\sound_SRatings\\analysis\\AUG25")
#normalise similarity ratings
final_dataset <- data_demog
normalized_ratings <- list()
# loop through each unique ID
for (id in unique(final_dataset$ID)) {
  # Subset the data for the current ID
  subset_data <- subset(final_dataset, ID == id)
  # Calculate max and min ratings for the current ID
  max_rating <- max(subset_data$sim_ratings)
  min_rating <- min(subset_data$sim_ratings)
  # Normalize the ratings
  subset_data$N_sim_ratings <- (subset_data$sim_ratings - min_rating) / (max_rating - min_rating)
  # Append the normalized ratings to the list
  normalized_ratings[[id]] <- subset_data}
# Combine the normalized ratings for all IDs into a single data frame
n_data <- do.call(rbind, normalized_ratings)

df_sr <- n_data
df_sr$nosets2A <- as.numeric(df_sr$nosets2A)
df_sr$nosets2B <- as.numeric(df_sr$nosets2B)
df_sr$step <- abs(df_sr$nosets2A - df_sr$nosets2B)
#add variable for same and different objects
df_sr$sdobj <- ifelse(df_sr$step == "0", "Same Object", "Different Object")
df_sr$soundtype <- ifelse(df_sr$soundA == df_sr$soundB, "Same_Sound", "Diff_Sound")
df_sr$soundAB <- paste(df_sr$soundA, "-", df_sr$soundB)
df_sr$condition <- as.factor(df_sr$condition)
df_sr$sound_condition <- as.factor(df_sr$sound_condition)
df_sr$soundAB <- as.factor(df_sr$soundAB)
levels(df_sr$soundAB) <- c("360rotation - 360rotation","360rotation - abrup_movement", "360rotation - vibration",
                        "360rotation - abrup_movement", "abrup_movement - abrup_movement", "abrup_movement - jump",          
                        "abrup_movement - vibration","jump - 360rotation" , "abrup_movement - jump",          
                        "jump - jump","jump - swing","jump - vibration" ,              
                        "silence - silence","swing - 360rotation","swing - abrup_movement",
                        "swing - swing","swing - vibration", "360rotation - vibration",      
                        "abrup_movement - vibration","jump - vibration", "swing - vibration",
                        "vibration - vibration")

#check for conditions/ missing data
ezDesign(df_sr, y = soundAB,  x = condition)
table(df_sr$soundAB)
write.table(df_sr, file = "C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\sMDS\\sound_SRatings\\analysis\\JUNE25\\n_data_lmer.csv",  sep= ",")

#different sound dataset for sound
setwd("C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\sMDS\\sound_SRatings\\analysis\\JUNE25\\lmers")

df_sr <- n_data_lmer
df_sr$sex <- as.factor(df_sr$sex)
df_sr$age <- as.numeric(df_sr$age)
df_sr$condition <- as.factor(df_sr$condition)
df_sr$condition <- factor(df_sr$condition, levels=c("static", "samemov", "diffmov"))
levels(df_sr$condition) <-  c("Static", "Consistent","Inconsistent")
df_sr$sdobj <- as.factor(df_sr$sdobj)
df_sr$sound_condition<-as.factor(df_sr$sound_condition)
levels(df_sr$sound_condition)<- c("No sound", "Sound")
#for sd as bars
df_sr2 <- df_sr %>%
  group_by(condition, sound_condition, sdobj) %>%
  summarise(sim_ratings= mean(N_sim_ratings),
            sim_ratings_SD= sd(N_sim_ratings),
            rt_ms= mean(rt_ms))

plot_pilot_data <- ggplot(data =  df_sr, aes(x = condition, y = N_sim_ratings, col = sound_condition , group = sound_condition)) + 
  stat_summary(geom = 'pointrange', alpha = 0.9, size = 1) +
  stat_summary(geom = 'line', alpha = 0.5, linewidth = 0.9) +
  #geom_errorbar(aes(ymin = sim_ratings - sim_ratings_SD, ymax = sim_ratings + sim_ratings_SD))+
  facet_wrap(~sdobj) +
  theme_classic() +
  labs(title = "Similarity ratings across motion and sound condtions", x = "Motion Condition", y = "Normalised similarity ratings",
       fill= "Sound Condition") +
  scale_color_manual(values = c( "darkblue","darkgreen")) +
  theme(legend.position = "top",
        axis.text.x = element_text(angle = 45, hjust = 1))+
  ylim(c(0,1))
plot_pilot_data
ggsave('raw_sound_motion.jpg', plot_pilot_data, width = 9, height = 6, dpi = 300)

plot_pilot_data <- ggplot(data =  df_sr, aes(x = sound_condition, y = N_sim_ratings, col = condition, group = condition)) + 
  stat_summary(geom = 'pointrange', alpha = 0.7, size = 1) +
  stat_summary(geom = 'line', alpha = 0.5, linewidth = 0.9) +
  facet_wrap(~sdobj) +
  theme_classic()+
  labs(title = "Similarity ratings across motion and sound condtions", x = "Sound condition", y = "Normalised similarity ratings",
       fill= "Motion Condition") +
  scale_color_manual(values = c( "darkblue","olivedrab", "indianred2")) +
  theme(legend.position = "top")+
  ylim(c(0,1))
plot_pilot_data

#check if the model show you the predicted estimation/P of similarity based on motion conditions 
#check for individual variability in the effect of movement across participants - plot it 
ggplot(data = df_sr, aes(x = sound_condition, y = sim_ratings, col = ID, group = ID)) + 
  stat_summary(geom = 'pointrange', alpha = 0.7, size = 1) +
  stat_summary(geom = 'line', alpha = 0.5) +
  #facet_wrap(~sound_condition) +
  theme_classic() +
  ylim(c(1,7))+
  theme(legend.position = 'none', axis.text.x = element_text(angle  = 45, hjust = 1))
#the effect of movement condition (i.e., the slope) is not consistent across participants thus we need to use the model
# to take it into account (not possible with anova)
df_sr$age_scaled <- scale(df_sr$age)
#check to see if the model is improved if we include a random slope for condition
lmer1_withslope <- lmer(N_sim_ratings ~ age_scaled + condition + sdobj + sound_condition +
                          condition*sdobj + sound_condition*sdobj + condition*sound_condition +
                          condition*sdobj*sound_condition +
                          (1 + condition+sound_condition|ID), 
                        data = df_sr)
summary(lmer1_withslope)
lmer1_noslope <- lmer(N_sim_ratings ~ age_scaled +condition + sdobj + sound_condition +
                        condition*sdobj + sound_condition*sdobj + condition*sound_condition +
                        condition*sdobj*sound_condition +
                        (1 + condition|ID), 
                      data = df_sr)
summary(lmer1_noslope)
anova(lmer1_noslope, lmer1_withslope) 
#adding motion as random slope does  improves model fit
'                 npar     AIC     BIC  logLik -2*log(L)  Chisq Df Pr(>Chisq)    
lmer1_noslope     15 1254.74 1369.24 -612.37   1224.74                         
lmer1_withslope   20 -274.96 -122.29  157.48   -314.96 1539.7  5  < 2.2e-16 ***'
#adding sound as random slope does  improves model fit
'                npar     AIC     BIC logLik -2*log(L)  Chisq Df Pr(>Chisq)    
lmer1_noslope     20 -274.96 -122.29 157.48   -314.96                         
lmer1_withslope   24 -787.89 -604.68 417.94   -835.89 520.93  4  < 2.2e-16 ***'

#run the model with the random slope included
#check for interaction effect  3way
lmer1 <- lmer(N_sim_ratings ~ age_scaled +condition + sdobj + sound_condition+
                condition*sdobj + sound_condition*sdobj + condition*sound_condition+
                condition*sdobj*sound_condition+
                (1 + condition|ID), 
              data = df_sr)
summary(lmer1)
lmer1_noint <- lmer(N_sim_ratings ~ age_scaled +condition + sdobj + sound_condition+
                      condition*sdobj + sound_condition*sdobj + condition*sound_condition+
                      (1 + condition|ID), 
                    data = df_sr)
summary(lmer1_noint)
anova(lmer1, lmer1_noint) 
#sig 3 way interaction condition*sdobj*sound_condition_ then consider the model lmer1_noint
'            npar     AIC     BIC logLik -2*log(L)  Chisq Df Pr(>Chisq)   
lmer1_noint   18 -265.24 -127.84 150.62   -301.24                        
lmer1         20 -274.96 -122.29 157.48   -314.96 13.718  2    0.00105 **'

#summary of the model
library(gtsummary)

lmer1 %>% tbl_regression() %>% bold_labels() %>%
  as_gt() |>  # convert to gt table
  gt::gtsave( # save table as image
    filename = "int_model_table_sMDS.png"
  )
lmer1_noint %>% tbl_regression() %>% bold_labels() %>%
  as_gt() |>  # convert to gt table
  gt::gtsave( # save table as image
    filename = "2wayint_model_table_sMDS.png"
  )
#plot of the model
library(jtools)
model1_sr_smds<- plot_model(lmer1_noint)+
  theme_apa()+
  geom_hline(yintercept = 0, color = "black", linetype = "solid", linewidth = 0.5) +
  theme(legend.position = "top")+
  labs(title = "a)")
model1_sr_smds
ggsave("model_sMDS_estimates.png", model1_sr_smds,width =6, height = 4, dpi = 300)

gg2 <- ggeffect(lmer1, terms = c("condition","sdobj","sound_condition"))
gg2
"# Predicted values of N_sim_ratings
sdobj: Different Object
sound_condition: No sound

condition    | Predicted |     95% CI
-------------------------------------
Static       |      0.59 | 0.55, 0.63
Consistent   |      0.71 | 0.68, 0.73
Inconsistent |      0.58 | 0.54, 0.61

sdobj: Different Object
sound_condition: Sound

condition    | Predicted |     95% CI
-------------------------------------
Static       |      0.55 | 0.51, 0.59
Consistent   |      0.70 | 0.67, 0.73
Inconsistent |      0.61 | 0.57, 0.65

sdobj: Same Object
sound_condition: No sound

condition    | Predicted |     95% CI
-------------------------------------
Static       |      0.86 | 0.82, 0.90
Consistent   |      0.86 | 0.83, 0.89
Inconsistent |      0.78 | 0.74, 0.82

sdobj: Same Object
sound_condition: Sound

condition    | Predicted |     95% CI
-------------------------------------
Static       |      0.86 | 0.82, 0.91
Consistent   |      0.86 | 0.83, 0.89
Inconsistent |      0.77 | 0.73, 0.82"

#check for 2ways interaction  
lmer2 <- lmer(N_sim_ratings ~ age_scaled +condition + sdobj + sound_condition+
                condition*sdobj + sound_condition*sdobj + condition*sound_condition+
                (1 + condition|ID), 
              data = df_sr)
summary(lmer2)
lmer2_noint <- lmer(N_sim_ratings ~ age_scaled +condition + sdobj + sound_condition+
                      condition*sdobj +sound_condition*sdobj +
                      (1 + condition|ID), 
                    data = df_sr)
summary(lmer2_noint)
anova(lmer2, lmer2_noint)
#for sound_condition*sdobj - NO EFFECT
'             npar     AIC     BIC logLik -2*log(L)  Chisq Df Pr(>Chisq)
lmer2_noint   17 -267.19 -137.42 150.60   -301.19                     
lmer2         18 -265.24 -127.84 150.62   -301.24 0.0506  1     0.8221'
#for condition*sound_condition - sign EFFECT
'            npar     AIC     BIC logLik -2*log(L) Chisq Df Pr(>Chisq)    
lmer2_noint   16 -241.21 -119.08 136.61   -273.21                        
lmer2         18 -265.24 -127.84 150.62   -301.24 28.03  2   8.19e-07 ***'

#for condition*sdobj - SIGNIFICANT 
'            npar      AIC      BIC  logLik -2*log(L)  Chisq Df Pr(>Chisq)    
lmer2_noint   16  -72.791   49.347  52.395   -104.79                         
lmer2         18 -265.244 -127.840 150.622   -301.24 196.45  2  < 2.2e-16 ***'

#main effects
lmer3<- lmer(N_sim_ratings ~ age_scaled +condition + sdobj + sound_condition+
                (1 + condition|ID), 
              data = df_sr)
summary(lmer3)
lmer3_noint <- lmer(N_sim_ratings ~ age_scaled + sdobj + condition+
                      (1 + condition|ID), 
                    data = df_sr)
summary(lmer3_noint)
anova(lmer3, lmer3_noint)
#condition
"            npar     AIC    BIC logLik -2*log(L)  Chisq Df Pr(>Chisq)    
lmer3_noint   11 -15.347 68.622 18.674   -37.347                         
lmer3         13 -51.139 48.098 38.569   -77.139 39.792  2  2.287e-09 ***"
#object pairing
"            npar     AIC    BIC   logLik -2*log(L) Chisq Df Pr(>Chisq)
lmer3_noint   12 2281.89 2373.5 -1128.94   2257.89                    
lmer3         13  -51.14   48.1    38.57    -77.14  2335  1  < 2.2e-16"
#sound
"             npar     AIC    BIC logLik -2*log(L)  Chisq Df Pr(>Chisq)
lmer3_noint   12 -52.463 39.140 38.232   -76.463                     
lmer3         13 -51.139 48.098 38.569   -77.139 0.6757  1     0.4111"

#final model
final_model <- lmer(N_sim_ratings ~ age_scaled + condition + sdobj+
                      condition*sdobj+condition*sound_condition+
                                     (1 + condition|ID), 
                                   data = df_sr)
summary(final_model)


#summary of the model
final_model %>% tbl_regression() %>% bold_labels() %>%
  as_gt() |>  # convert to gt table
  gt::gtsave( # save table as image
    filename = "final_model_table_sMDS.png"
  )

#coeffients
library(performance)
model_metrics <- model_performance(final_model)
model_metrics

model_performance(lmer1_noint)$RMSE
"# Indices of model performance

AIC      |     AICc |     BIC | R2 (cond.) | R2 (marg.) |   ICC |  RMSE | Sigma
-------------------------------------------------------------------------------
-192.217 | -192.177 | -62.446 |      0.358 |      0.145 | 0.250 | 0.234 | 0.235"
getwd()
#posthoc values -2way
post_learn = emmeans(final_model, pairwise~condition, type = 'response', adjust = 'bonferroni', 
                     pbkrtest.limit = 15269, lmerTest.limit = 15269)
results_learn <- post_learn$contrasts %>% rbind()
results_learn 
results_CI_learn <- 
  confint(results_learn)
results_CI_learn 
" contrast                  estimate     SE   df t.ratio p.value
 Static - Consistent        -0.0663 0.0161 62.3  -4.108  0.0004
 Static - Inconsistent       0.0317 0.0229 61.1   1.388  0.5105
 Consistent - Inconsistent   0.0981 0.0193 61.6   5.083  <.0001
> results_CI_learn 
 contrast                  estimate     SE   df lower.CL upper.CL
 Static - Consistent        -0.0663 0.0161 62.3  -0.1061  -0.0266
 Static - Inconsistent       0.0317 0.0229 61.1  -0.0245   0.0880
 Consistent - Inconsistent   0.0981 0.0193 61.6   0.0506   0.1456"

#condition*sdobj
post_learn = emmeans(final_model, pairwise~condition*sdobj, type = 'response', adjust = 'bonferroni', 
                     pbkrtest.limit = 15269, lmerTest.limit = 15269)
results_learn <- post_learn$contrasts %>% rbind()
results_learn 
"contrast                                                    estimate      SE      df t.ratio p.value
 Static Different Object - Consistent Different Object       -0.13425 0.01630    64.1  -8.254  <.0001 *
 Static Different Object - Inconsistent Different Object     -0.02456 0.02290    62.0  -1.070  1.0000
 Static Different Object - Static Same Object                -0.29631 0.00731 15080.1 -40.520  <.0001 *
 Static Different Object - Consistent Same Object            -0.29474 0.01700    75.7 -17.385  <.0001*
 Static Different Object - Inconsistent Same Object          -0.20828 0.02340    67.5  -8.886  <.0001*
 Consistent Different Object - Inconsistent Different Object  0.10970 0.01940    62.9   5.657  <.0001*
 Consistent Different Object - Static Same Object            -0.16206 0.01700    75.8  -9.557  <.0001*
 Consistent Different Object - Consistent Same Object        -0.16048 0.00730 15080.2 -21.981  <.0001*
 Consistent Different Object - Inconsistent Same Object      -0.07402 0.02000    70.7  -3.706  0.0062*
 Inconsistent Different Object - Static Same Object          -0.27176 0.02340    67.6 -11.591  <.0001*
 Inconsistent Different Object - Consistent Same Object      -0.27018 0.02000    70.8 -13.527  <.0001*
 Inconsistent Different Object - Inconsistent Same Object    -0.18372 0.00729 15080.0 -25.199  <.0001*
 Static Same Object - Consistent Same Object                  0.00157 0.01760    88.3   0.089  1.0000
 Static Same Object - Inconsistent Same Object                0.08804 0.02390    73.3   3.680  0.0066*
 Consistent Same Object - Inconsistent Same Object            0.08646 0.02050    79.0   4.210  0.0010*"
results_CI_learn <- 
  confint(results_learn)
results_CI_learn 
" contrast                                                    estimate      SE      df lower.CL upper.CL
 Static Different Object - Consistent Different Object       -0.13425 0.01630    64.1  -0.1838  -0.0847
 Static Different Object - Inconsistent Different Object     -0.02456 0.02290    62.0  -0.0946   0.0455
 Static Different Object - Static Same Object                -0.29631 0.00731 15080.1  -0.3178  -0.2748
 Static Different Object - Consistent Same Object            -0.29474 0.01700    75.7  -0.3461  -0.2434
 Static Different Object - Inconsistent Same Object          -0.20828 0.02340    67.5  -0.2796  -0.1369
 Consistent Different Object - Inconsistent Different Object  0.10970 0.01940    62.9   0.0505   0.1689
 Consistent Different Object - Static Same Object            -0.16206 0.01700    75.8  -0.2135  -0.1107
 Consistent Different Object - Consistent Same Object        -0.16048 0.00730 15080.2  -0.1819  -0.1391
 Consistent Different Object - Inconsistent Same Object      -0.07402 0.02000    70.7  -0.1347  -0.0133
 Inconsistent Different Object - Static Same Object          -0.27176 0.02340    67.6  -0.3431  -0.2004
 Inconsistent Different Object - Consistent Same Object      -0.27018 0.02000    70.8  -0.3309  -0.2095
 Inconsistent Different Object - Inconsistent Same Object    -0.18372 0.00729 15080.0  -0.2051  -0.1623
 Static Same Object - Consistent Same Object                  0.00157 0.01760    88.3  -0.0516   0.0547
 Static Same Object - Inconsistent Same Object                0.08804 0.02390    73.3   0.0154   0.1606
 Consistent Same Object - Inconsistent Same Object            0.08646 0.02050    79.0   0.0243   0.1486"

#condition*sound_condition
post_learn = emmeans(final_model, pairwise~condition*sound_condition, type = 'response', adjust = 'bonferroni', 
                     pbkrtest.limit = 15269, lmerTest.limit = 15269)
results_learn <- post_learn$contrasts %>% rbind()
results_learn 
"contrast                                    estimate      SE      df t.ratio p.value
 Static No sound - Consistent No sound       -0.05638 0.01680    73.2  -3.354  0.0190*
 Static No sound - Inconsistent No sound      0.05629 0.02330    66.3   2.412  0.2795
 Static No sound - Static Sound               0.02618 0.00660 15080.3   3.965  0.0011*
 Static No sound - Consistent Sound          -0.05013 0.01680    73.2  -2.982  0.0582
 Static No sound - Inconsistent Sound         0.03337 0.02330    66.3   1.430  1.0000
 Consistent No sound - Inconsistent No sound  0.11267 0.01990    69.0   5.676  <.0001*
 Consistent No sound - Static Sound           0.08255 0.01680    73.2   4.911  0.0001*
 Consistent No sound - Consistent Sound       0.00625 0.00659 15080.1   0.947  1.0000
 Consistent No sound - Inconsistent Sound     0.08974 0.01980    69.0   4.521  0.0004*
 Inconsistent No sound - Static Sound        -0.03011 0.02330    66.3  -1.290  1.0000
 Inconsistent No sound - Consistent Sound    -0.10642 0.01980    69.0  -5.361  <.0001*
 Inconsistent No sound - Inconsistent Sound  -0.02292 0.00659 15080.0  -3.479  0.0076*
 Static Sound - Consistent Sound             -0.07631 0.01680    73.2  -4.539  0.0003*
 Static Sound - Inconsistent Sound            0.00719 0.02330    66.3   0.308  1.0000
 Consistent Sound - Inconsistent Sound        0.08349 0.01980    69.0   4.207  0.0011*"
results_CI_learn <- 
  confint(results_learn)
results_CI_learn 
"contrast                                    estimate      SE      df lower.CL  upper.CL
 Static No sound - Consistent No sound       -0.05638 0.01680    73.2  -0.1074 -0.005366
 Static No sound - Inconsistent No sound      0.05629 0.02330    66.3  -0.0148  0.127355
 Static No sound - Static Sound               0.02618 0.00660 15080.3   0.0068  0.045556
 Static No sound - Consistent Sound          -0.05013 0.01680    73.2  -0.1011  0.000878
 Static No sound - Inconsistent Sound         0.03337 0.02330    66.3  -0.0377  0.104428
 Consistent No sound - Inconsistent No sound  0.11267 0.01990    69.0   0.0523  0.173027
 Consistent No sound - Static Sound           0.08255 0.01680    73.2   0.0315  0.133564
 Consistent No sound - Consistent Sound       0.00625 0.00659 15080.1  -0.0131  0.025606
 Consistent No sound - Inconsistent Sound     0.08974 0.01980    69.0   0.0294  0.150100
 Inconsistent No sound - Static Sound        -0.03011 0.02330    66.3  -0.1012  0.040954
 Inconsistent No sound - Consistent Sound    -0.10642 0.01980    69.0  -0.1668 -0.046059
 Inconsistent No sound - Inconsistent Sound  -0.02292 0.00659 15080.0  -0.0423 -0.003582
 Static Sound - Consistent Sound             -0.07631 0.01680    73.2  -0.1273 -0.025295
 Static Sound - Inconsistent Sound            0.00719 0.02330    66.3  -0.0639  0.078255
 Consistent Sound - Inconsistent Sound        0.08349 0.01980    69.0   0.0231  0.143852"

#plots
#plot the model NO3way interaction
lmer1_3wayint<- plot_model(lmer1, type = "eff", terms = c("condition","sdobj","sound_condition")) +
  theme_apa()+
  labs(x ="Motion conditions",y="Normalised Similarity Ratings", title= " ",
       color = "Object Pairing") +
  theme(legend.position = "top")+
  ylim(c(0.5, 1))
lmer1_3wayint
ggsave('3WAY_similarity_model.png', lmer1_3wayint, width = 7, height = 4, dpi = 300)

lmer1_2ways<- plot_model(final_model, type = "eff", terms = c("condition","sdobj")) +
  theme_apa()+
  labs(x ="Motion conditions",y="Normalised Similarity Ratings", title= "A)",
       color = "Object Pairing") +
  theme(legend.position = "top",axis.text.x = element_text(angle  = 45, hjust = 1))+
  ylim(c(0.5, 1))
lmer1_2ways
ggsave('2WAY_similarity_model.png', lmer1_2ways, width = 6, height = 6, dpi = 300)

lmer2_2ways<- plot_model(final_model, type = "eff", terms = c("condition","sound_condition")) +
  theme_apa()+
  labs(x ="Motion conditions",y="Normalised Similarity Ratings", title= "B)",
       color = "Sound Condition") +
  theme(legend.position = "top",axis.text.x = element_text(angle  = 45, hjust = 1))+
  ylim(c(0.5, 1))
lmer2_2ways
ggsave('2WAY_similarity_model.2.png', lmer2_2ways, width = 6, height = 6, dpi = 300)

#paper figure
plot_combined <- ggarrange(lmer1_2ways,lmer2_2ways, ncol =2, nrow=1)
plot_combined
ggsave('Figure4.1.jpg', plot_combined, width = 8, height = 6, dpi = 300)

#REACTION TIMES ------
#explore data with individual data points  - for raw data
gg3 <- ggplot(df_sr, aes(x=step, y=rt_ms, fill = step, col = step))+
  geom_jitter(size= 1, alpha = 0.3) +
  stat_summary(geom = 'point', size = 4, fun = 'median') +
  facet_wrap(~condition)
gg3
ggsave('rawdata_rt_MOTION.png', gg3, width = 6, height = 6, dpi = 300)

#Remove outliers - exclusion criteria- RTs and cut off 
#a - GROUP cut_off - at least 3 SDs above the mean 
df_rt <- df_sr
upper_cut_off <- mean(df_rt$rt_ms) + 2.5*(sd(df_rt$rt_ms))
lower_cut_off <- mean(df_rt$rt_ms) - 2.5*(sd(df_rt$rt_ms))
d_groupcutoff<- subset(df_rt, rt_ms < upper_cut_off & rt_ms > lower_cut_off)
df_rt$outlier_RT <- ifelse(df_rt$rt_ms > upper_cut_off |
                             df_rt$rt_ms < lower_cut_off, 'Yes', 'No')
table(df_rt$outlier_RT)
df_rt_noGroupoutliers <- subset(df_rt, outlier_RT == 'No')
#b - INDIVIDUAL cut-off - 4 SDs above the individual mean
df_rt_Indcutoff <- df_rt_noGroupoutliers %>% group_by(ID) %>%
  filter(rt_ms < mean(rt_ms) + (4 * sd(rt_ms)), rt_ms > mean(rt_ms) - (4 * sd(rt_ms)))
boxplot(df_rt_Indcutoff$rt_ms)
hist(df_rt_Indcutoff$rt_ms)
range(df_rt_Indcutoff$rt_ms)
#c - check people with RT below 500 ms 
d_below500 <- subset(df_rt_noGroupoutliers, rt_ms < 250) # 50 participant with RT fastest of 150 ms
summary(d_below500)

#checkfor%data excluded
n_total <- nrow(df_rt)
df_rt_noGroupoutliers <- subset(df_rt, outlier_RT == 'No')
df_rt_Indcutoff <- df_rt_noGroupoutliers %>%
  group_by(ID) %>%
  filter(rt_ms < mean(rt_ms) + (4 * sd(rt_ms)),
         rt_ms > mean(rt_ms) - (4 * sd(rt_ms)))
df_final <- subset(df_rt_Indcutoff, rt_ms >= 250)
n_final <- nrow(df_final)
total_exclusion <- (1 - (n_final / n_total)) * 100
cat("Total % of data excluded after all cutoffs:", round(total_exclusion, 2), "%\n")

df_rt_noout <- subset(df_rt_noGroupoutliers, rt_ms > 250)
df_rt_final <- df_rt_noout %>%
  group_by(sound_condition,step,condition  ) %>%
  summarise(sim_ratings= mean(N_sim_ratings),
            mean_rt_ms= mean(rt_ms),
            sd_rt =sd(rt_ms))
df_rt_noout$condition <- as.factor(df_rt_noout$condition)
levels(df_rt_noout$condition)
df_rt_noout$sound_condition <- as.factor(df_rt_noout$sound_condition)
df_rt_noout$age <- as.numeric(df_rt_noout$age)
df_rt_noout$age_scaled <- scale(df_rt_noout$age)

#check for the random slope
lmer1RT__withslope <- lmer(rt_ms ~ age_scaled + condition + sdobj + sound_condition +
                             condition*sdobj + sound_condition*sdobj + condition*sound_condition +
                             condition*sdobj* sound_condition+
                             (1 + condition|ID), 
                           data = df_rt_noout)
summary(lmer1RT__withslope)
lmer1RT__noslope <- lmer(rt_ms ~ age_scaled +condition + sdobj + sound_condition +
                           condition*sdobj + sound_condition*sdobj + condition*sound_condition +
                           condition*sdobj* sound_condition+
                           (1|ID), 
                         data = df_rt_noout)
summary(lmer1RT__noslope)
anova(lmer1RT__withslope, lmer1RT__noslope) 
#adding random slope does improves model fit
'                    npar    AIC    BIC  logLik -2*log(L)  Chisq Df Pr(>Chisq)    
lmer1RT__noslope     13 216169 216268 -108071    216143                         
lmer1RT__withslope   18 215309 215445 -107636    215273 870.18  5  < 2.2e-16 ***'

#run the model with the random slope included
#check 3way interaction
lmer1RT <- lmer(rt_ms ~ age_scaled + condition + sdobj + sound_condition +
                  condition*sdobj + sound_condition*sdobj + condition*sound_condition +
                  (1 + condition|ID), 
                data = df_rt_noout)
summary(lmer1RT)
lmer1RT_noint <- lmer(rt_ms ~ age_scaled + condition + sdobj + sound_condition +
                        condition*sdobj + sound_condition*sdobj  +
                        (1 + condition|ID), 
                      data = df_rt_noout)
summary(lmer1RT_noint)
anova(lmer1RT, lmer1RT_noint)
#3way interaction - none
"              npar    AIC    BIC  logLik -2*log(L)  Chisq Df Pr(>Chisq)
lmer1RT_noint   18 215309 215445 -107636    215273                     
lmer1RT         20 215313 215464 -107636    215273 0.3164  2     0.8537"
#2ways
#condition*sdobj  - no effect 
'               npar    AIC    BIC  logLik -2*log(L)  Chisq Df Pr(>Chisq)
lmer1RT_noint   16 215308 215429 -107638    215276                     
lmer1RT         18 215309 215445 -107636    215273 3.2167  2     0.2002'
#sound_condition*sdobj- no effect
'              npar    AIC    BIC  logLik -2*log(L)  Chisq Df Pr(>Chisq)
lmer1RT_noint   17 215309 215438 -107637    215275                     
lmer1RT         18 215309 215445 -107636    215273 1.8884  1     0.1694'
#condition*sound_condition - no effect  (0.067)
'              npar    AIC    BIC  logLik -2*log(L)  Chisq Df Pr(>Chisq)  
lmer1RT_noint   16 215310 215431 -107639    215278                       
lmer1RT         18 215309 215445 -107636    215273 5.1618  2    0.07571 .'
#main effects
#sdobj - SIGNIFICANT
'npar    AIC    BIC  logLik -2*log(L)  Chisq Df Pr(>Chisq)    
lmer1RT_noint   12 215326 215417 -107651    215302                         
lmer1RT         13 215309 215408 -107642    215283 18.838  1  1.423e-05 ****'
#motion  - SIGNIFICANT
'             npar    AIC    BIC  logLik -2*log(L)  Chisq Df Pr(>Chisq)  
lmer1RT_noint   11 215313 215397 -107646    215291                       
lmer1RT         13 215309 215408 -107642    215283 8.3758  2    0.01518 *'
#sound
"              npar    AIC    BIC  logLik -2*log(L)  Chisq Df Pr(>Chisq)
lmer1RT_noint   12 215307 215398 -107642    215283                     
lmer1RT         13 215309 215408 -107642    215283 0.0093  1      0.9"
#FINAL MODEL
lmer1RT_final <- lmer(rt_ms ~ age_scaled + condition + sdobj +
                        (1 + condition|ID), 
                      data = df_rt_noout)
summary(lmer1RT_final)

#plot of the model
model1_rt_smds<- plot_model(lmer1RT_final)+
  theme_apa()+
  geom_hline(yintercept = 1, color = "black", linetype = "solid", linewidth = 0.5) +
  theme(legend.position = "top")+
  labs(title = "b)")
model1_rt_smds
ggsave("model_sMDS_eRTSstimates.png", model1_rt_smds,width =4, height = 4, dpi = 300)

#posthoc values
post_learn = emmeans(lmer1RT_final, pairwise~condition, type = 'response', adjust = 'bonferroni',
                     pbkrtest.limit = 15269, lmerTest.limit = 15269)
results_learn <- post_learn$contrasts %>% rbind()
results_learn 
results_CI_learn <- 
  confint(results_learn)
results_CI_learn 
'contrast                  estimate   SE   df t.ratio p.value
Static - Consistent           57.7 28.0 59.8   2.063  0.1304
Static - Inconsistent        -14.0 27.4 59.8  -0.509  1.0000
Consistent - Inconsistent    -71.7 25.1 59.9  -2.859  0.0175 *
  contrast                  estimate   SE   df lower.CL upper.CL
Static - Consistent           57.7 28.0 59.8    -11.2   126.67
Static - Inconsistent        -14.0 27.4 59.8    -81.5    53.61
Consistent - Inconsistent    -71.7 25.1 59.9   -133.5    -9.94'

" contrast                       estimate  SE  df z.ratio p.value
 Different Object - Same Object     31.7 7.3 Inf   4.342  <.0001
 contrast                       estimate  SE  df asymp.LCL asymp.UCL
 Different Object - Same Object     31.7 7.3 Inf      17.4        46"

gg2 <- ggeffect(lmer1RT_final, terms = c("sdobj"))
gg2
"condition          | Predicted |           95% CI
-------------------------------------------------
Static             |   1212.63 | 1111.23, 1314.03
Same movement      |   1140.93 | 1038.85, 1243.01
Different movement |   1198.66 | 1088.44, 1308.89
sdobj            | Predicted |           95% CI
-----------------------------------------------
Different Object |   1193.04 | 1092.82, 1293.27
Same Object      |   1161.36 | 1060.69, 1262.03"

#plot the model for single effects
lmer1RT_plot<- plot_model(lmer1RT_final, type = "eff", terms = c("sdobj")) +
  theme_apa()+
  labs(x ="Motion conditions",y="Reaction times", title= "C)", color = "Object pairings")+
  theme(legend.title = element_text("Object pairings"), legend.position = "top",
        axis.text.x = element_text(angle  = 45, hjust = 1))+
  ylim(c(700, 1500))
lmer1RT_plot
ggsave('RTs_model_motion.png', lmer1RT_plot, width = 4, height = 4, dpi = 300)
ggsave('RTs_model_sdobj.png', lmer1RT_plot, width = 8, height = 8, dpi = 300)

####paper figure###
plot_combined <- ggarrange(lmer1_2ways,lmer2_2ways,lmer1RT_plot, ncol =3, nrow=1)
plot_combined
ggsave('Figure4.jpg', plot_combined, width = 10, height = 6, dpi = 300)


#extra check of different object pairs according to step size and motion and sound
levels(df_sr$sdobj)
diff_obj <- subset(df_sr, sdobj == "Different Object")
diff_obj_ns <- diff_obj %>%
  group_by(ID, condition, step) %>%
  summarise(sim_ratings= mean(N_sim_ratings),
            sim_ratings_SD= sd(N_sim_ratings),
            rt_ms= mean(rt_ms))
print(diff_obj_ns)

diff_obj_ns$condition <- factor(diff_obj_ns$condition)
diff_obj_ns$step <- factor(diff_obj_ns$step)
diff_obj_ns$ID <- factor(diff_obj_ns$ID)

#violation of sphericity -> models
library(car)
leveneTest(sim_ratings ~ condition, data = diff_obj_ns)
"Levene's Test for Homogeneity of Variance (center = median)
       Df F value    Pr(>F)    
group   2  13.493 1.679e-06 ***
      912    "

mod_int<- lmer(sim_ratings ~ condition * step + 
                 condition + step + 
              (1 + condition| ID), 
            data = diff_obj_ns)
summary(mod_int)
mod_noint<- lmer(sim_ratings ~ condition + step + 
                 (1 + condition| ID), 
               data = diff_obj_ns)
summary(mod_noint)
anova(mod_int, mod_noint) 
 #interaction contributes 
"mod_noint: sim_ratings ~ condition + step + (1 + condition | ID)
mod_int: sim_ratings ~ condition * step + condition + step + (1 + condition | ID)
          npar     AIC     BIC logLik -2*log(L)  Chisq Df Pr(>Chisq)  
mod_noint   14 -1333.9 -1266.5 680.97   -1361.9                       
mod_int     22 -1333.5 -1227.5 688.76   -1377.5 15.597  8    0.04853 *"

post_learn = emmeans(mod, ~condition*step, type = 'response', adjust = 'bonferroni',
                     pbkrtest.limit = 15269, lmerTest.limit = 15269)
pairs(post_learn, by = "step", adjust = "bonferroni")
"step = 1:
 contrast                  estimate     SE    df t.ratio p.value
 Static - Consistent        -0.1179 0.0289 103.5  -4.082  0.0003
 Static - Inconsistent       0.0123 0.0316  93.7   0.390  1.0000
 Consistent - Inconsistent   0.1302 0.0261 119.7   4.997  <.0001

step = 2:
 contrast                  estimate     SE    df t.ratio p.value
 Static - Consistent        -0.1310 0.0289 103.5  -4.534  <.0001
 Static - Inconsistent      -0.0266 0.0316  93.7  -0.839  1.0000
 Consistent - Inconsistent   0.1044 0.0261 119.7   4.007  0.0003

step = 3:
 contrast                  estimate     SE    df t.ratio p.value
 Static - Consistent        -0.1570 0.0289 103.5  -5.437  <.0001
 Static - Inconsistent      -0.0524 0.0316  93.7  -1.657  0.3025
 Consistent - Inconsistent   0.1046 0.0261 119.7   4.015  0.0003

step = 4:
 contrast                  estimate     SE    df t.ratio p.value
 Static - Consistent        -0.1400 0.0289 103.5  -4.848  <.0001
 Static - Inconsistent      -0.0503 0.0316  93.7  -1.589  0.3464
 Consistent - Inconsistent   0.0898 0.0261 119.7   3.445  0.0024

step = 5:
 contrast                  estimate     SE    df t.ratio p.value
 Static - Consistent        -0.1441 0.0289 103.5  -4.987  <.0001
 Static - Inconsistent      -0.0629 0.0316  93.7  -1.988  0.1492
 Consistent - Inconsistent   0.0812 0.0261 119.7   3.115  0.0069

Degrees-of-freedom method: kenward-roger 
P value adjustment: bonferroni method for 3 tests "

results_CI_learn <- 
  confint(results_learn)
results_CI_learn 
" contrast                                estimate     SE    df  lower.CL upper.CL
 step1
 Static step1 - Consistent step1         -0.11789 0.0289 103.5 -0.222117  -0.0137
 Static step1 - Inconsistent step1        0.01233 0.0316  93.7 -0.102221   0.1269
 Consistent step1 - Inconsistent step1    0.13022 0.0261 119.7  0.036601   0.2238

Step 2
 Static step2 - Consistent step2         -0.13097 0.0289 103.5 -0.235198  -0.0267
 Static step2 - Inconsistent step2       -0.02655 0.0316  93.7 -0.141102   0.0880
 Consistent step2 - Inconsistent step2    0.10442 0.0261 119.7  0.010801   0.1980

Step3
 Static step3 - Consistent step3         -0.15704 0.0289 103.5 -0.261271  -0.0528
 Static step3 - Inconsistent step3       -0.05242 0.0316  93.7 -0.166972   0.0621
 Consistent step3 - Inconsistent step3    0.10462 0.0261 119.7  0.011004   0.1982

Step4
 Static step4 - Consistent step4         -0.14003 0.0289 103.5 -0.244261  -0.0358
 Static step4 - Inconsistent step4       -0.05026 0.0316  93.7 -0.164810   0.0643
 Consistent step4 - Inconsistent step4    0.08977 0.0261 119.7 -0.003844   0.1834

Step5
 Static step5 - Consistent step5         -0.14405 0.0289 103.5 -0.248277  -0.0398
 Static step5 - Inconsistent step5       -0.06288 0.0316  93.7 -0.177432   0.0517
 Consistent step5 - Inconsistent step5    0.08117 0.0261 119.7 -0.012450   0.1748"

#odds ratio
plodel1_extra<- plot_model(mod_int)+
  theme_apa()+
  geom_hline(yintercept = 1, color = "black", linetype = "solid", linewidth = 0.5) +
  theme(legend.position = "top")+
  labs(title = "")
model1_extra
ggsave('plodel1_extraEMM.png', plodel1_extra, width = 8, height = 6, dpi = 300)

#plot the model for single effects
plodel1_extra_eff<- plot_model(mod_int, type = "eff", terms = c("step", "condition")) +
  theme_apa()+
  geom_smooth(method = "lm", size = 0.8, alpha = 0.2) +
  labs(x ="Step",y="Normalised Similarity Ratings", title= "C)", color = "Condition")+
  theme(legend.position = "top") +
  labs(title = "")+
  ylim(c(0,1))
plodel1_extra_eff
ggsave('plodel1_extra.png', plodel1_extra_eff, width = 5, height = 5, dpi = 300)

library(dplyr)
library(ggplot2)

# 1. Summarize means and SEs for each condition × step
plot_data <- diff_obj_ns %>%
  group_by(condition, step) %>%
  summarise(mean_rating = mean(sim_ratings),
            se = sd(sim_ratings)/sqrt(n()),
            .groups = "drop")

# 2. Manually define significance labels for each step
# Here, based on your post-hoc results (example for Consistent vs others)
sig_labels <- data.frame(
  step = rep(1:5, each = 3),
  condition1 = rep(c("Static","Static","Consistent"), times = 5),
  condition2 = rep(c("Consistent","Inconsistent","Inconsistent"), times = 5),
  label = c("***", "", "***", "***", "", "***", "***", "", "***", "***", "", "***", "***", "", "***")
)

# 3. Plot
ggplot(plot_data, aes(x = as.numeric(step), y = mean_rating, color = condition, group = condition)) +
  geom_line(size = 1) +
  geom_point(size = 3) +
  #geom_errorbar(aes(ymin = mean_rating - se, ymax = mean_rating + se), width = 0.2) +
  scale_x_continuous(breaks = 1:5, labels = 1:5) +
  labs(x = "Step", y = "Normalised Similarity rating", color = "Condition",
       title = "Similarity Ratings Across Motion Conditions") +
  theme_apa()+
  scale_color_brewer(palette = "Set1") +
  # Optional: add manual significance text
  geom_text(data = sig_labels %>% filter(label != ""),
            aes(x = step, y = 0.85, label = label), 
            inherit.aes = FALSE, color = "black", size = 5)
