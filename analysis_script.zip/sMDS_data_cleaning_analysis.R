#### Install Packages ####
pkg <- c("factoextra", "NbClust")
models <- c("lme4","performance","effects","ggplot2")
install.packages(pkg)
install.packages(models)
install.packages("scales")
install.packages("lme4")
install.packages("wordcloud")
install.packages("wordcloud2")
install.packages("tm")
#### Load Packages ####
#for general functions 
library(ggplot2)
library(broom)
library(car)
library(caret)
library(plyr)
library(psych)
library(tidyverse)
library(dplyr)
library(reshape2)
library(qwraps2) 
library(devtools)
library(tidytext)
library(rstatix)
library(fmsb)
library(rcompanion)
library(Rmisc)
library(purrr)
#for sample matching 
library(MatchIt)
library(optmatch)
#for plotting
library(cowplot)
library(dotwhisker)
library(GGally)
library(ggeffects)
library(gridExtra)
library(ggpubr)
library(jtools)
library(sjPlot)
library(effects)
library(latticeExtra)
library(corrplot)
library(RColorBrewer)
library(jcolors)
library(plotly)
library(gplots)
library(ggthemes)
library(ggstance)
library(dplyr)
library(stats)
library(ez)
#remotes::install_github("ricardo-bion/ggradar")
library(networkD3)
library(wesanderson)
#for K means clustering and analyses 
library(kml)
library(kml3d)
library(lme4)
library(DHARMa)
library(broom.mixed)
library(jtools)
#load for models

library(lme4)
library(emmeans)
library(afex)
library(nloptr)
library(optimx)
library(performance)
#for model convergence issues 
library(optimx)
library(parallel)
library(minqa) 
#for MDS
library(magrittr)
library(dplyr)
library(ggpubr)
library(MASS)
library(factoextra)
library(NbClust)
#### Data cleaning ####
getwd()
setwd("C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\sMDS\\sound_SRatings\\data")
#load in datafiles to global environment from working directory - 
  #make sure these files are in the same directory then import csv
temp = list.files(pattern="*.csv")
for (i in 1:length(temp)) assign(temp[i], read.csv(temp[i]))
objs <- mget(ls(envir = globalenv()))
library(purrr)
dfs <- objs[map_lgl(objs, is.data.frame)]

#merge the different datafiles 
similarity_data <- reduce(dfs, full_join)
#turn participant turn into a factor 
similarity_data$participant <- as.factor(similarity_data$participant)
#number of rows per datafile per participant 
table(similarity_data$participant)

####Demographics####
names(similarity_data)
#create a list of columns we want called 'cols'
cols <- c('participant', 'demographic.Sex', 'demographic.Age' ,'demographic.normalvision', 'demographic.normal.hearing', 
          'demographic.Education', 'demographic.Level.Education', 'demographic.Browser' )
#create a new file 'm_demo': R will 
#match the names in cols to the column names in the datafile and extract them
demog <- similarity_data[cols]
#remove duplicate columns and NA columns 
m_demo2 <- demog[!duplicated(demog), ]
demogfinal <- m_demo2[complete.cases(m_demo2),]
demog$participant <- as.factor(demog$participant)
levels(demogfinal$participant)  
demog <- demogfinal

colnames(demog)[1] <- 'ID'
colnames(demog)[2] <- 'sex'
colnames(demog)[3] <- 'age'
colnames(demog)[4] <- 'normal_vision'
colnames(demog)[5] <- 'normal_hearing'
colnames(demog)[6] <- 'completed_edu'
colnames(demog)[7] <- 'level_edu'
colnames(demog)[8] <- 'browser'

demog$sex <- as.factor(demog$sex)
demog$age <- as.integer(demog$age)
demog$normal_vision <- as.factor(demog$normal_vision)
demog$normal_hearing <- as.factor(demog$normal_hearing)
demog$completed_edu <- as.factor(demog$completed_edu)
demog$level_edu <- as.factor(demog$level_edu)
demog$browser <- as.factor(demog$browser)
#logic
levels(demog$sex) <- c('Male', 'Female')
levels(demog$normal_vision) <-  c('Yes')
levels(demog$normal_hearing) <-  c('Yes')
levels(demog$completed_edu) <- c('No','Yes')
levels(demog$level_edu) <-  c('Primary School', 'Secondary School', 'Third level or higher')
levels(demog$browser) <-  c('Chrome', 'Edge', 'Firefox')

demographic_summary <-demog %>%
  group_by(ID, sex) %>%
  summarise(age=mean(age))

mean(demographic_summary$age)
sd(demographic_summary$age)

summary(demog$sex)
summary(demog$normal_vision)
summary(demog$normal_hearing)
summary(demog$completed_edu)
summary(demog$level_edu)
summary(demog$browser)
write.table(demog, file = "C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\sMDS\\sound_SRatings\\analysis\\df\\demographics.csv",  sep= ",")

#### word clouds for qualitative responses ####
setwd("C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\sMDS\\sound_SRatings\\analysis\\strategy")
cols2 <- c('participant', 'textbox_2.text')
strategy <- similarity_data[cols2]
strategy <- strategy[!duplicated(strategy), ]
strategy <- strategy[complete.cases(strategy),]
strategy$participant <- as.factor(strategy$participant)
levels(strategy$participant) 
colnames(strategy)[2] <- "response"
# Load libraries
library(tm)
library(wordcloud)
library(wordcloud2)
library(ggplot2)
library(dplyr)
strategy_2 <- subset(strategy, select = response)
strategy_2 <- unlist(strategy_2)
# Create a text corpus
text <- strategy_2
docs <- Corpus(VectorSource(text))
# Clean the text data
docs <- docs %>%
  tm_map(removeNumbers) %>%
  tm_map(removePunctuation) %>%
  tm_map(stripWhitespace)
docs <- tm_map(docs, content_transformer(tolower))
docs <- tm_map(docs, removeWords, stopwords("english"))
# Create a term-document matrix
dtm <- TermDocumentMatrix(docs)
matrix <- as.matrix(dtm)
words <- sort(rowSums(matrix), decreasing = TRUE)
df <- data.frame(word = names(words), freq = words, stringsAsFactors = FALSE)
print(str(df))  # Should be a data.frame
print(head(df)) # Check first few rows

set.seed(1234)# Set seed for reproducibility
my_colors <- c("indianred", "aquamarine4", "olivedrab", "hotpink4", "orange2", "darkturquoise")
wordcloud(words = df$word, freq = df$freq, min.freq = 1,          
          max.words = 200, random.order = FALSE, rot.per = 0.35,            
          colors = my_colors)
png("wordcloud.png", width = 800, height = 600)  # Adjust size if needed
write.table(strategy, file = "C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\sMDS\\sound_SRatings\\analysis\\strategy\\strategy.csv",  sep= ",")
# Extract top 10 words
df_top10 <- df[1:10, ]
colour_bar <- 'skyblue4'
qual_bar <- ggplot(df_top10, aes(x = reorder(word, -freq), y = freq, fill = colour_bar)) +
  geom_bar(stat = 'identity', colour = 'black') +
  ggtitle("Top 10 Words in Responses") +
  theme_classic() +
  labs(x = 'Top 10 words', y = 'Frequency (n)') +
  theme(legend.position = 'none',
        plot.background = element_rect(fill = "white"),
        legend.title = element_blank(),
        legend.text = element_text(size = 12),
        axis.title = element_text(size = 14),
        axis.text = element_text(size = 12),
        strip.text = element_text(size = 14))
print(qual_bar)
ggsave('10_words.png', qual_bar, width = 8, height = 6, dpi = 300)
qualitative_combined <- ggarrange(qual_bar,qual_bar, ncol =2, nrow=1)

glimpse(similarity_data)
#####SR_static####
setwd("C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\sMDS\\sound_SRatings\\analysis\\df")
cols <- c('participant', 'group','condition', 'movement_type', 'sound_condition', 'set','Step','stimA','movA','soundA','stimB','movB', 'soundB',
          'slider_s.response', 'slider_s.rt')
s_ratings <- similarity_data[cols]
#remove NAs 
s_ratings2 <- s_ratings[!duplicated(s_ratings), ]
static_ratings <- s_ratings2[complete.cases(s_ratings2),]
static_ratings$participant <- as.factor(static_ratings$participant)
levels(static_ratings$participant)  
s_ratings<-static_ratings

colnames(s_ratings)[1] <- 'ID'
colnames(s_ratings)[2] <- 'group(1-6)'
colnames(s_ratings)[3] <- 'condition'
colnames(s_ratings)[4] <- 'movement_type'
colnames(s_ratings)[5] <- 'sound_condition'
colnames(s_ratings)[6] <- 'stim_set'
colnames(s_ratings)[7] <- 'step'
colnames(s_ratings)[8] <- 'A'
colnames(s_ratings)[9] <- 'movA'
colnames(s_ratings)[10] <- 'soundA'
colnames(s_ratings)[11] <- 'B'
colnames(s_ratings)[12] <- 'movB'
colnames(s_ratings)[13] <- 'soundB'
colnames(s_ratings)[14] <- 's_ratings'
colnames(s_ratings)[15] <- 's_rt'

s_ratings$condition <- as.factor(s_ratings$condition)
levels(s_ratings$condition) <- ("static")
s_ratings$movement_type <- as.factor(s_ratings$movement_type)
levels(s_ratings$movement_type)
s_ratings$sound_condition <- as.factor(s_ratings$sound_condition)
levels(s_ratings$sound_condition) <- c("no_sound", "sound")
s_ratings$stim_set <- as.factor(s_ratings$stim_set)
levels(s_ratings$stim_set)
s_ratings$step <- as.factor(s_ratings$step)
levels(s_ratings$step)
s_ratings$A <- as.factor(s_ratings$A)
levels(s_ratings$A)
s_ratings$B <- as.factor(s_ratings$B)
levels(s_ratings$B)
s_ratings$movA <- as.factor(s_ratings$movA)
levels(s_ratings$movA)
s_ratings$movB <- as.factor(s_ratings$movB)
levels(s_ratings$movB)
s_ratings$soundA <- as.factor(s_ratings$soundA)
levels(s_ratings$soundA) <- c("360rotation", "abrup_movement", "jump", "silence", "swing", "vibration")
s_ratings$soundB <- as.factor(s_ratings$soundB)
levels(s_ratings$soundB)<- c("360rotation", "abrup_movement", "jump", "silence", "swing", "vibration")

#normalise RTs and change to milliseconds
s_ratings$RTs_ms<- s_ratings$s_rt*1000
#compute means
mean(s_ratings$RTs_ms)
sd(s_ratings$RTs_ms)

#add stimuli set info
levels(s_ratings$A)
s_ratings$stimset <- ifelse(s_ratings$A %in% c ("1" , "2",  "3",  "4"  ,"5"  ,"6",  "7",  "8"  ,"9"  ,"10", "11", "12"), "setA",
                       ifelse(s_ratings$A %in% c("13" ,"14", "15", "16" ,"17" ,"18", "19", "20", "21" ,"22", "23" ,"24"), "setB",
                              ifelse(s_ratings$A %in% c("25", "26" ,"27" ,"28" ,"29" ,"30" ,"31" ,"32" ,"33" ,"34" ,"35", "36"), "setC", "NOSET")))
s_ratings$nosetsA <- s_ratings$A
levels(s_ratings$nosetsA) <- c("1" , "2",  "3",  "4"  ,"5"  ,"6",  "7",  "8"  ,"9"  ,"10", "11", "12" ,
                          "1" , "2",  "3",  "4"  ,"5"  ,"6",  "7",  "8"  ,"9"  ,"10", "11", "12" ,
                          "1" , "2",  "3",  "4"  ,"5"  ,"6",  "7",  "8"  ,"9"  ,"10", "11", "12" )
s_ratings$nosetsB <-s_ratings$B
levels(s_ratings$nosetsB) <- c("1" , "2",  "3",  "4"  ,"5"  ,"6",  "7",  "8"  ,"9"  ,"10", "11", "12" ,
                          "1" , "2",  "3",  "4"  ,"5"  ,"6",  "7",  "8"  ,"9"  ,"10", "11", "12" ,
                          "1" , "2",  "3",  "4"  ,"5"  ,"6",  "7",  "8"  ,"9"  ,"10", "11", "12" )

s_ratings$nosets2A <- s_ratings$A
levels(s_ratings$nosets2A) <- c("1" , "2",  "3",  "4"  ,"5"  ,"6", "1" , "2",  "3",  "4"  ,"5"  ,"6",
                                 "1" , "2",  "3",  "4"  ,"5"  ,"6", "1" , "2",  "3",  "4"  ,"5"  ,"6",
                                 "1" , "2",  "3",  "4"  ,"5"  ,"6",  "1" , "2",  "3",  "4"  ,"5"  ,"6" )
s_ratings$nosets2B <-s_ratings$B
levels(s_ratings$nosets2B) <- c("1" , "2",  "3",  "4"  ,"5"  ,"6", "1" , "2",  "3",  "4"  ,"5"  ,"6",
                                 "1" , "2",  "3",  "4"  ,"5"  ,"6", "1" , "2",  "3",  "4"  ,"5"  ,"6",
                                 "1" , "2",  "3",  "4"  ,"5"  ,"6",  "1" , "2",  "3",  "4"  ,"5"  ,"6" )

#clean dataset
names(s_ratings)
cols3 <- c("ID","condition", "movement_type", "sound_condition", "stimset", "nosets2A", "nosets2B", "A","soundA","B", "soundB",'s_ratings','RTs_ms')
f_static <- s_ratings[cols3]
f_static$condition <- as.factor(f_static$condition)
f_static$movement_type <- as.factor(f_static$movement_type)
f_static$stimset <- as.factor(f_static$stimset)
#final_df$step <- as.factor(final_df$step)
f_static$A <- as.factor(f_static$A)
f_static$B <- as.factor(f_static$B)
f_static$nosets2A <- as.factor(f_static$nosets2A)
f_static$nosets2B <- as.factor(f_static$nosets2B)
colnames(f_static)[12] <- 'sim_ratings'
colnames(f_static)[13] <- 'rt_ms'
write.table(f_static, file = "C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\sMDS\\sound_SRatings\\analysis\\df\\f_static.csv",  sep= ",")

##SR_samemov
cols <- c('participant', 'group','condition', 'movement_type', 'sound_condition', 'set','Step','stimA','movA','soundA','stimB','movB', 'soundB',
          'slider_sm.response', 'slider_sm.rt')
sm_ratings <- similarity_data[cols]
#remove NAs 
sm_ratings2 <- sm_ratings[!duplicated(sm_ratings), ]
samemov_ratings <- sm_ratings2[complete.cases(sm_ratings2),]
samemov_ratings$participant <- as.factor(samemov_ratings$participant)
levels(samemov_ratings$participant)  
sm_ratings<-samemov_ratings

colnames(sm_ratings)[1] <- 'ID'
colnames(sm_ratings)[2] <- 'group(1-6)'
colnames(sm_ratings)[3] <- 'condition'
colnames(sm_ratings)[4] <- 'movement_type'
colnames(sm_ratings)[5] <- 'sound_condition'
colnames(sm_ratings)[6] <- 'stim_set'
colnames(sm_ratings)[7] <- 'step'
colnames(sm_ratings)[8] <- 'A'
colnames(sm_ratings)[9] <- 'movA'
colnames(sm_ratings)[10] <- 'soundA'
colnames(sm_ratings)[11] <- 'B'
colnames(sm_ratings)[12] <- 'movB'
colnames(sm_ratings)[13] <- 'soundB'
colnames(sm_ratings)[14] <- 'sm_ratings'
colnames(sm_ratings)[15] <- 'sm_rt'

sm_ratings$condition <- as.factor(sm_ratings$condition)
levels(sm_ratings$condition) <- ("samemov")
sm_ratings$movement_type <- as.factor(sm_ratings$movement_type)
levels(sm_ratings$movement_type)
sm_ratings$sound_condition <- as.factor(sm_ratings$sound_condition)
levels(sm_ratings$sound_condition) <- c("no_sound", "sound")
sm_ratings$stim_set <- as.factor(sm_ratings$stim_set)
levels(sm_ratings$stim_set)
sm_ratings$step <- as.factor(sm_ratings$step)
levels(sm_ratings$step)
sm_ratings$A <- as.factor(sm_ratings$A)
levels(sm_ratings$A)
sm_ratings$B <- as.factor(sm_ratings$B)
levels(sm_ratings$B)
sm_ratings$movA <- as.factor(sm_ratings$movA)
levels(sm_ratings$movA)
sm_ratings$movB <- as.factor(sm_ratings$movB)
levels(sm_ratings$movB)
sm_ratings$soundA <- as.factor(sm_ratings$soundA)
levels(sm_ratings$soundA) <- c("360rotation", "abrup_movement", "jump", "silence", "swing", "vibration")
sm_ratings$soundB <- as.factor(sm_ratings$soundB)
levels(sm_ratings$soundB)<- c("360rotation", "abrup_movement", "jump", "silence", "swing", "vibration")

sm_ratings$RTsm_ms<- sm_ratings$sm_rt*1000
#compute means
mean(sm_ratings$RTsm_ms)
sd(sm_ratings$RTsm_ms)
#add stimuli set info
levels(sm_ratings$A)
sm_ratings$stimset <- ifelse(sm_ratings$A %in% c ("1" , "2",  "3",  "4"  ,"5"  ,"6",  "7",  "8"  ,"9"  ,"10", "11", "12"), "setA",
                            ifelse(sm_ratings$A %in% c("13" ,"14", "15", "16" ,"17" ,"18", "19", "20", "21" ,"22", "23" ,"24"), "setB",
                                   ifelse(sm_ratings$A %in% c("25", "26" ,"27" ,"28" ,"29" ,"30" ,"31" ,"32" ,"33" ,"34" ,"35", "36"), "setC", "NOSET")))
sm_ratings$nosetsA <- sm_ratings$A
levels(sm_ratings$nosetsA) <- c("1" , "2",  "3",  "4"  ,"5"  ,"6",  "7",  "8"  ,"9"  ,"10", "11", "12" ,
                               "1" , "2",  "3",  "4"  ,"5"  ,"6",  "7",  "8"  ,"9"  ,"10", "11", "12" ,
                               "1" , "2",  "3",  "4"  ,"5"  ,"6",  "7",  "8"  ,"9"  ,"10", "11", "12" )
sm_ratings$nosetsB <-sm_ratings$B
levels(sm_ratings$nosetsB) <- c("1" , "2",  "3",  "4"  ,"5"  ,"6",  "7",  "8"  ,"9"  ,"10", "11", "12" ,
                               "1" , "2",  "3",  "4"  ,"5"  ,"6",  "7",  "8"  ,"9"  ,"10", "11", "12" ,
                               "1" , "2",  "3",  "4"  ,"5"  ,"6",  "7",  "8"  ,"9"  ,"10", "11", "12" )

sm_ratings$nosets2A <- sm_ratings$A
levels(sm_ratings$nosets2A) <- c("1" , "2",  "3",  "4"  ,"5"  ,"6", "1" , "2",  "3",  "4"  ,"5"  ,"6",
                                "1" , "2",  "3",  "4"  ,"5"  ,"6", "1" , "2",  "3",  "4"  ,"5"  ,"6",
                                "1" , "2",  "3",  "4"  ,"5"  ,"6",  "1" , "2",  "3",  "4"  ,"5"  ,"6" )
sm_ratings$nosets2B <-sm_ratings$B
levels(sm_ratings$nosets2B) <- c("1" , "2",  "3",  "4"  ,"5"  ,"6", "1" , "2",  "3",  "4"  ,"5"  ,"6",
                                 "1" , "2",  "3",  "4"  ,"5"  ,"6", "1" , "2",  "3",  "4"  ,"5"  ,"6",
                                 "1" , "2",  "3",  "4"  ,"5"  ,"6",  "1" , "2",  "3",  "4"  ,"5"  ,"6" )

#clean dataset
names(sm_ratings)
cols3 <- c("ID","condition", "movement_type", "stimset","sound_condition", "nosets2A", "nosets2B", "A","soundA","B", "soundB",'sm_ratings','RTsm_ms')
f_samemov<- sm_ratings[cols3]
f_samemov$condition <- as.factor(f_samemov$condition)
levels(f_samemov$condition)
f_samemov$movement_type <- as.factor(f_samemov$movement_type)
f_samemov$stimset <- as.factor(f_samemov$stimset)
#final_df$step <- as.factor(final_df$step)
f_samemov$A <- as.factor(f_samemov$A)
f_samemov$B <- as.factor(f_samemov$B)
f_samemov$nosets2A <- as.factor(f_samemov$nosets2A)
f_samemov$nosets2B <- as.factor(f_samemov$nosets2B)
colnames(f_samemov)[12] <- 'sim_ratings'
colnames(f_samemov)[13] <- 'rt_ms'

write.table(f_static, file = "C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\sMDS\\sound_SRatings\\analysis\\df\\f_samemov.csv",  sep= ",")

##SR_diffmov
cols <- c('participant', 'group','condition', 'movement_type', 'sound_condition', 'set','Step','stimA','movA','soundA','stimB','movB', 'soundB',
          'slider_dm.response', 'slider_dm.rt')
dm_ratings <- similarity_data[cols]
#remove NAs 
dm_ratings2 <- dm_ratings[!duplicated(dm_ratings), ]
diffmov_ratings <- dm_ratings2[complete.cases(dm_ratings2),]
diffmov_ratings$participant <- as.factor(diffmov_ratings$participant)
levels(diffmov_ratings$participant)  
dm_ratings<-diffmov_ratings

colnames(dm_ratings)[1] <- 'ID'
colnames(dm_ratings)[2] <- 'group(1-6)'
colnames(dm_ratings)[3] <- 'condition'
colnames(dm_ratings)[4] <- 'movement_type'
colnames(dm_ratings)[5] <- 'sound_condition'
colnames(dm_ratings)[6] <- 'stim_set'
colnames(dm_ratings)[7] <- 'step'
colnames(dm_ratings)[8] <- 'A'
colnames(dm_ratings)[9] <- 'movA'
colnames(dm_ratings)[10] <- 'soundA'
colnames(dm_ratings)[11] <- 'B'
colnames(dm_ratings)[12] <- 'movB'
colnames(dm_ratings)[13] <- 'soundB'
colnames(dm_ratings)[14] <- 'dm_ratings'
colnames(dm_ratings)[15] <- 'dm_rt'

dm_ratings$condition <- as.factor(dm_ratings$condition)
levels(dm_ratings$condition) <- ("diffmov")
dm_ratings$movement_type <- as.factor(dm_ratings$movement_type)
levels(dm_ratings$movement_type)
dm_ratings$sound_condition <- as.factor(dm_ratings$sound_condition)
levels(dm_ratings$sound_condition) <- c("no_sound", "sound")
dm_ratings$stim_set <- as.factor(dm_ratings$stim_set)
levels(dm_ratings$stim_set)
dm_ratings$step <- as.factor(dm_ratings$step)
levels(dm_ratings$step)
dm_ratings$A <- as.factor(dm_ratings$A)
levels(dm_ratings$A)
dm_ratings$B <- as.factor(dm_ratings$B)
levels(dm_ratings$B)
dm_ratings$movA <- as.factor(dm_ratings$movA)
levels(dm_ratings$movA)
dm_ratings$movB <- as.factor(dm_ratings$movB)
levels(dm_ratings$movB)
dm_ratings$soundA <- as.factor(dm_ratings$soundA)
levels(dm_ratings$soundA) <- c("360rotation", "jump", "silence", "swing", "vibration")
dm_ratings$soundB <- as.factor(dm_ratings$soundB)
levels(dm_ratings$soundB) <- c("360rotation", "abrup_movement", "silence", "swing", "vibration")
dm_ratings$RTdm_ms<- dm_ratings$dm_rt*1000
#compute means
mean(dm_ratings$RTdm_ms)
sd(dm_ratings$RTdm_ms)

#add stimuli set info
levels(dm_ratings$A)
dm_ratings$stimset <- ifelse(dm_ratings$A %in% c ("1" , "2",  "3",  "4"  ,"5"  ,"6",  "7",  "8"  ,"9"  ,"10", "11", "12"), "setA",
                             ifelse(dm_ratings$A %in% c("13" ,"14", "15", "16" ,"17" ,"18", "19", "20", "21" ,"22", "23" ,"24"), "setB",
                                    ifelse(dm_ratings$A %in% c("25", "26" ,"27" ,"28" ,"29" ,"30" ,"31" ,"32" ,"33" ,"34" ,"35", "36"), "setC", "NOSET")))
dm_ratings$nosetsA <- dm_ratings$A
levels(dm_ratings$nosetsA) <- c("1" , "2",  "3",  "4"  ,"5"  ,"6",  "7",  "8"  ,"9"  ,"10", "11", "12" ,
                                "1" , "2",  "3",  "4"  ,"5"  ,"6",  "7",  "8"  ,"9"  ,"10", "11", "12" ,
                                "1" , "2",  "3",  "4"  ,"5"  ,"6",  "7",  "8"  ,"9"  ,"10", "11", "12" )
dm_ratings$nosetsB <-dm_ratings$B
levels(dm_ratings$nosetsB) <- c("1" , "2",  "3",  "4"  ,"5"  ,"6",  "7",  "8"  ,"9"  ,"10", "11", "12" ,
                                "1" , "2",  "3",  "4"  ,"5"  ,"6",  "7",  "8"  ,"9"  ,"10", "11", "12" ,
                                "1" , "2",  "3",  "4"  ,"5"  ,"6",  "7",  "8"  ,"9"  ,"10", "11", "12" )
dm_ratings$nosets2A <- dm_ratings$A
levels(dm_ratings$nosets2A) <- c("1" , "2",  "3",  "4"  ,"5"  ,"6", "1" , "2",  "3",  "4"  ,"5"  ,"6",
                                 "1" , "2",  "3",  "4"  ,"5"  ,"6", "1" , "2",  "3",  "4"  ,"5"  ,"6",
                                 "1" , "2",  "3",  "4"  ,"5"  ,"6",  "1" , "2",  "3",  "4"  ,"5"  ,"6" )
dm_ratings$nosets2B <-dm_ratings$B
levels(dm_ratings$nosets2B) <- c("1" , "2",  "3",  "4"  ,"5"  ,"6", "1" , "2",  "3",  "4"  ,"5"  ,"6",
                                 "1" , "2",  "3",  "4"  ,"5"  ,"6", "1" , "2",  "3",  "4"  ,"5"  ,"6",
                                 "1" , "2",  "3",  "4"  ,"5"  ,"6",  "1" , "2",  "3",  "4"  ,"5"  ,"6" )

#clean dataset
names(dm_ratings)
cols3 <- c("ID","condition", "movement_type","sound_condition", "stimset", "nosets2A", "nosets2B", "A", "soundA","B", "soundB",'dm_ratings','RTdm_ms')
f_diffmov<- dm_ratings[cols3]
f_diffmov$condition <- as.factor(f_diffmov$condition)
f_diffmov$movement_type <- as.factor(f_diffmov$movement_type)
f_diffmov$stimset <- as.factor(f_diffmov$stimset)
f_diffmov$A <- as.factor(f_diffmov$A)
f_diffmov$B <- as.factor(f_diffmov$B)
f_diffmov$nosets2A <- as.factor(f_diffmov$nosets2A)
f_diffmov$nosets2B <- as.factor(f_diffmov$nosets2B)
colnames(f_diffmov)[12] <- 'sim_ratings'
colnames(f_diffmov)[13] <- 'rt_ms'

write.table(f_static, file = "C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\sMDS\\sound_SRatings\\analysis\\df\\f_diffmov.csv",  sep= ",")

#finaldataset and get variables and levels
final_dataset <- rbind(f_static, f_samemov, f_diffmov)
final_datasetdemog <- final_dataset
final_datasetdemog <- merge(demog,final_dataset, by = 'ID')
glimpse(final_datasetdemog)
write.table(final_datasetdemog,file = "C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\sMDS\\sound_SRatings\\analysis\\df\\final_dataset_demographics.csv",  sep= ",")

final_dataset <- final_datasetdemog
# Initialize an empty list to store the normalized ratings
normalized_ratings <- list()
# Loop through each unique ID
for (id in unique(final_dataset$ID)) {
  # Subset the data for the current ID
  subset_data <- subset(final_dataset, ID == id)
    # Calculate max and min ratings for the current ID
  max_rating <- max(subset_data$sim_ratings)
  min_rating <- min(subset_data$sim_ratings)
  # Normalize the ratings
  subset_data$N_sim_ratings <- (subset_data$sim_ratings - min_rating) / (max_rating - min_rating)
    # Append the normalized ratings to the list
  normalized_ratings[[id]] <- subset_data}
# Combine the normalized ratings for all IDs into a single data frame
normalized_ratings_df <- do.call(rbind, normalized_ratings)
#merge with demog
final_Ndataset_demog <- merge(demog, normalized_ratings_df, by ="ID")
write.table(final_Ndataset_demog,file = "C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\sMDS\\sound_SRatings\\analysis\\df\\normalised_finaldf.csv",  sep= ",")

####SR analysis####
df <- normalized_ratings_df
df$nosets2A <- as.numeric(df$nosets2A)
df$nosets2B <- as.numeric(df$nosets2B)
df$step <- abs(df$nosets2A - df$nosets2B)
#add variable for same and different objects
df$sdobj <- ifelse(df$step == "0", "Same Object", "Different Object")
df$soundtype <- ifelse(df$soundA == df$soundB, "Same_Sound", "Diff_Sound")
df$soundAB <- paste(df$soundA, "-", df$soundB)

df$condition <- as.factor(df$condition)
df$sound_condition <- as.factor(df$sound_condition)
df$soundAB <- as.factor(df$soundAB)

levels(df$soundAB) <- c("360rotation - 360rotation","360rotation - abrup_movement", "360rotation - vibration",
                        "360rotation - abrup_movement", "abrup_movement - abrup_movement", "abrup_movement - jump",          
                        "abrup_movement - vibration","jump - 360rotation" , "abrup_movement - jump",          
                        "jump - jump","jump - swing","jump - vibration" ,              
                        "silence - silence","swing - 360rotation","swing - abrup_movement",
                        "swing - swing","swing - vibration", "360rotation - vibration",      
                        "abrup_movement - vibration","jump - vibration", "swing - vibration",
                        "vibration - vibration")
###check for conditions/ missing data
ezDesign(df, y = soundAB,  x = condition)
table(df$soundAB)
#different sound dataset for sound
df1 <- subset(df, soundtype =="Same_Sound")
df2 <- subset(df, soundtype =="Diff_Sound")
#
setwd("C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\sMDS\\sound_SRatings\\analysis\\lmer")
write.table(df, file = "C:\\Users\\sevesom\\OneDrive - Trinity College Dublin\\Documents\\Studies\\Data\\MOC_mov\\sMDS\\sound_SRatings\\analysis\\df\\df_lmer.csv",  sep= ",")
#group by important variables - only for SAME /DIFFERENT OBJECTS
dfSUM <- df %>%
  group_by(ID, condition, sound_condition, sdobj, movement_type) %>%
  summarise(sim_ratings= mean(N_sim_ratings),
            rt_ms= mean(rt_ms))
#prep dataset 
dfSUM <- merge(demog, dfSUM, by ="ID")
dfSUM$sex <- as.factor(dfSUM$sex)
dfSUM$age <- as.numeric(dfSUM$age)
dfSUM$condition <- as.factor(dfSUM$condition)
levels(dfSUM$condition)<-  c("Static","Same movement", "Different movement")
dfSUM$sdobj <- as.factor(dfSUM$sdobj)
dfSUM$sound_condition<-as.factor(dfSUM$sound_condition)
levels(dfSUM$sound_condition)<- c("No sound", "Sound")
#for sd as bars
dfSUM2 <- df %>%
  group_by(condition, sound_condition, sdobj) %>%
  summarise(sim_ratings= mean(N_sim_ratings),
            sim_ratings_SD= sd(N_sim_ratings),
            rt_ms= mean(rt_ms))
#explore data
plot_pilot_data <- ggplot(data =  dfSUM, aes(x = condition, y = sim_ratings, col = sound_condition , group = sound_condition)) + 
  stat_summary(geom = 'pointrange', alpha = 0.9, size = 1) +
  stat_summary(geom = 'line', alpha = 0.5, linewidth = 0.9) +
 #geom_errorbar(aes(ymin = sim_ratings - sim_ratings_SD, ymax = sim_ratings + sim_ratings_SD))+
  facet_wrap(~sdobj) +
  theme_classic() +
  labs(title = "Similarity ratings across motion and sound condtions", x = "Motion Condition", y = "Normalised similarity ratings",
       fill= "Sound Condition") +
  scale_color_manual(values = c( "darkblue","darkgreen")) +
  theme(legend.position = "top",
        axis.text.x = element_text(angle = 45, hjust = 1))+
  ylim(c(0,1))
plot_pilot_data
ggsave('raw_sound_motion.jpg', plot_pilot_data, width = 12, height = 6, dpi = 300)

plot_pilot_data <- ggplot(data =  dfSUM, aes(x = sound_condition, y = sim_ratings, col = condition, group = condition)) + 
  stat_summary(geom = 'pointrange', alpha = 0.7, size = 1) +
  stat_summary(geom = 'line', alpha = 0.5, linewidth = 0.9) +
  facet_wrap(~sdobj) +
  theme_classic()+
  labs(title = "Similarity ratings across motion and sound condtions", x = "Sound condition", y = "Normalised similarity ratings",
       fill= "Motion Condition") +
  scale_color_manual(values = c( "darkblue","olivedrab", "indianred2")) +
  theme(legend.position = "top")+
  ylim(c(0,1))
plot_pilot_data
ggsave('rawdata_sound_motion2.jpg', plot_pilot_data, width = 12, height = 6, dpi = 300)

#check SR model ~ motion & same/diffobject
#the model show you the predicted estimation/P of similarity based on motion conditions 
#check for individual variability in the effect of movement across participants - plot it 
ggplot(data = dfSUM, aes(x = condition, y = sim_ratings, col = ID, group = ID)) + 
  stat_summary(geom = 'pointrange', alpha = 0.7, size = 1) +
  stat_summary(geom = 'line', alpha = 0.5) +
  facet_wrap(~sound_condition) +
  theme_classic() +
  theme(legend.position = 'none', axis.text.x = element_text(angle  = 45, hjust = 1))
#the effect of movement condition (i.e., the slope) is not consistent across participants thus we need to use the model
# to take it into account (not possible with anova)

dfSUM$age_scaled <- scale(dfSUM$age)
#check to see if the model is improved if we include a random slope for condition
lmer1_withslope <- lmer(sim_ratings ~ age_scaled + condition + sdobj + sound_condition +
                        condition*sdobj + sound_condition*sdobj + condition*sound_condition +
                          condition*sdobj*sound_condition +
                          (1 + condition|ID), 
                        data = dfSUM)
lmer1_noslope <- lmer(sim_ratings ~ age_scaled +condition + sdobj + sound_condition +
                        condition*sdobj + sound_condition*sdobj + condition*sound_condition +
                        condition*sdobj*sound_condition +
                        (1|ID), 
                      data = dfSUM)
anova(lmer1_noslope, lmer1_withslope) #adding random slope does not improves model fit
'                npar     AIC     BIC logLik deviance  Chisq Df Pr(>Chisq)    
lmer1_noslope     15 -1188.4 -1098.0 609.18  -1218.4                         
lmer1_withslope   20 -1451.3 -1330.8 745.63  -1491.3 272.89  5  < 2.2e-16 ***'

#run the model with the random slope included
library(performance)
library(ggplot2)
theme_set(theme_classic(base_size= 6))
lmer1 <- lmer(sim_ratings ~ age_scaled +condition + sdobj + sound_condition+
               condition*sdobj + sound_condition*sdobj + condition*sound_condition+
                condition*sdobj*sound_condition+
                (1 + condition|ID), 
              data = dfSUM)
summary(lmer1)
lmer1_noint <- lmer(sim_ratings ~ age_scaled +condition + sdobj + sound_condition+
                      condition*sdobj + sound_condition*sdobj + condition*sound_condition+
                      (1 + condition|ID), 
                    data = dfSUM)
summary(lmer1_noint)
anova(lmer1, lmer1_noint) #sig 3 way interaction condition*sdobj*sound_condition_ then consider the model lmer1_noint
'            npar     AIC     BIC logLik deviance  Chisq Df Pr(>Chisq)
lmer1_noint   18 -1451.8 -1343.4 743.91  -1487.8                     
lmer1         20 -1451.3 -1330.8 745.63  -1491.3 3.4423  2     0.1789'
#plot the model NO3way interaction
lmer1_no3wayint<- plot_model(lmer1_noint, type = "eff", terms = c("condition","sound_condition","sdobj"), dot.size = 5, line.size = 0.5, alpha = 0.3) +
  theme_classic()+
  labs(x ="Motion conditions",y="Normalised Similarity Ratings", title= "Similarity ratings for same and different object pairings",
       color = "Sound condition") +
  theme(legend.position = "top",axis.text.x = element_text(angle  = 45, hjust = 1))+
  ylim(c(0, 1))
lmer1_no3wayint
ggsave('3WAY_similarity_model.png', lmer1_no3wayint, width = 8, height = 8, dpi = 300)

#check for 2ways interaction  
lmer2 <- lmer(sim_ratings ~ age_scaled +condition + sdobj + sound_condition+
                      condition*sdobj + sound_condition*sdobj + condition*sound_condition+
                      (1 + condition|ID), 
                    data = dfSUM)
summary(lmer2)
lmer2_noint <- lmer(sim_ratings ~ age_scaled +condition + sdobj + sound_condition+
                     sound_condition*sdobj + condition*sound_condition +
                (1 + condition|ID), 
              data = dfSUM)
summary(lmer2_noint)
anova(lmer2, lmer2_noint)

#for sound_condition*sdobj - NO EFFECT
'            npar     AIC     BIC logLik deviance  Chisq Df Pr(>Chisq)
lmer2_noint   17 -1452.2 -1349.8 743.10  -1486.2                     
lmer2         18 -1451.8 -1343.4 743.91  -1487.8 1.6186  1     0.2033'

#for condition*sound_condition - NO EFFECT
'            npar     AIC     BIC logLik deviance  Chisq Df Pr(>Chisq)
lmer2_noint   16 -1451.4 -1355.0 741.71  -1483.4                     
lmer2         18 -1451.8 -1343.4 743.91  -1487.8 4.4112  2     0.1102'

#for condition*sdobj - SIGNIFICANT 
'            npar     AIC     BIC logLik deviance  Chisq Df Pr(>Chisq)    
lmer2_noint   16 -1429.5 -1333.1 730.75  -1461.5                         
lmer2         18 -1451.8 -1343.4 743.91  -1487.8 26.329  2  1.918e-06 ***'
#this justify the division of the dataset in #Different Object / #Same Object
#plot the model with significant  interaction
lmer2.final <- lmer(sim_ratings ~ age_scaled +condition + sdobj + sound_condition+
                condition*sdobj +
                (1 + condition|ID), 
              data = dfSUM)
summary(lmer2.final)

lmer_2waysign_plot<- plot_model(lmer2.final, type = "eff", terms = c("condition", "sdobj"), dot.size = 5, line.size = 0.5, alpha = 0.3) +
  theme_classic()+
  labs(x ="Motion conditions",y="Normalised Similarity Ratings", title= "A)",
       color = "Condition") +
  theme(legend.position = "top",
        axis.text.x = element_text(angle  = 45, hjust = 1))+
  ylim(c(0, 1))
lmer_2waysign_plot
ggsave('2WAY_sim_model.png', lmer_2waysign_plot, width = 8, height = 8, dpi = 300)

###### dataset divided by same/ different object pairing ######
###SAME OBJECTS
df3_df <- subset(df,sdobj == "Same Object" )
df3 <- df3_df %>%
  group_by(ID, condition,sound_condition) %>%
  summarise(sim_ratings= mean(N_sim_ratings),
            rt_ms= mean(rt_ms))
df3 <- merge(demog, df3, by ="ID")
df3$sex <- as.factor(df3$sex)
df3$age <- as.numeric(df3$age)
df3$condition <- as.factor(df3$condition)
df3$condition <- factor(df3$condition, levels=c("static","samemov", "diffmov"))
levels(df3$condition) <-  c("Static","Same movement", "Different movement")
levels(df3$sound_condition)  <-  c("No sound","Sound")

#check for interactions 
lmer3<- lmer(sim_ratings ~ condition*sound_condition + 
               condition + sound_condition +
                (1|ID), 
              data = df3)
summary(lmer3)
lmer3_noint <- lmer(sim_ratings ~ sound_condition + condition +
                      (1|ID), 
                    data = df3)
summary(lmer3_noint)
anova(lmer3, lmer3_noint)
#condition*sound_condition - NO EFFECT
'            npar     AIC     BIC logLik deviance  Chisq Df Pr(>Chisq)
lmer3_noint    6 -589.54 -566.13 300.77  -601.54                     
lmer3          8 -585.62 -554.40 300.81  -601.62 0.0802  2     0.9607'
#CHECK FOR MAIN EFFECTS
lmer3.maineffects <- lmer(sim_ratings ~ sound_condition +
                      (1|ID), 
                    data = df3)
summary(lmer3.maineffects)
anova(lmer3.maineffects, lmer3_noint)
#sound_condition - NO EFFECT
'                  npar     AIC     BIC logLik deviance  Chisq Df Pr(>Chisq)
lmer3.maineffects    5 -591.51 -572.00 300.75  -601.51                     
lmer3_noint          6 -589.54 -566.13 300.77  -601.54 0.0324  1     0.8573'
#motion condition - SIGNIFICANT 
'                  npar     AIC     BIC logLik deviance  Chisq Df Pr(>Chisq)    
lmer3.maineffects    4 -521.54 -505.93 264.77  -529.54                         
lmer3_noint          6 -589.54 -566.13 300.77  -601.54 71.999  2  2.321e-16 ***'

#final model
lmer3.finalmodel <- lmer(sim_ratings ~ condition +
                            (1|ID), 
                          data = df3)
summary(lmer3.finalmodel)
#plot the model
lmer3.finalmodel_plot<- plot_model(lmer3.finalmodel, type = "eff", terms = c("condition"), dot.size = 5, line.size = 0.5, alpha = 0.3) +
  theme_classic()+
  labs(x ="Motion conditions",y="Normalised Similarity Ratings", title= "B)") +
  theme ( axis.text.x = element_text(angle  = 45, hjust = 1))+
  ylim(c(0,1))
lmer3.finalmodel_plot
ggsave('same_objects_SR_MOTION.png', lmer3.finalmodel_plot, width = 8, height = 6, dpi = 300)
#posthoc values
post_learn = emmeans(lmer3.finalmodel, pairwise~condition, type = 'response', adjust = 'bonferroni')
results_learn <- post_learn$contrasts %>% rbind()
results_learn 
#Effect: Different movement vs STATIC (p <.0001) AND SAME MOV (p<.0001)"
" contrast                           estimate     SE  df t.ratio p.value
 Static - Same movement              0.00152 0.0112 303   0.135  1.0000
 Static - Different movement         0.08820 0.0112 303   7.845  <.0001
 Same movement - Different movement  0.08668 0.0112 303   7.710  <.0001"
results_CI_learn <- 
  confint(results_learn)
results_CI_learn 
' contrast                           estimate     SE  df lower.CL upper.CL
 Static - Same movement              0.00152 0.0112 303  -0.0255   0.0286
 Static - Different movement         0.08820 0.0112 303   0.0611   0.1153
 Same movement - Different movement  0.08668 0.0112 303   0.0596   0.1137'

###DIFFERENT OBJECTS
df2.1 <- subset(df, sdobj == "Different Object" )
df2 <- df2.1 %>%
  group_by(ID, condition,sound_condition, step) %>%
  summarise(sim_ratings= mean(N_sim_ratings),
            rt_ms= mean(rt_ms))
df2 <- merge(demog, df2, by ="ID")
df2$sex <- as.factor(df2$sex)
df2$age <- as.numeric(df2$age)
df2$step <- as.factor(df2$step)
df2$condition <- as.factor(df2$condition)
df2$condition <- factor(df2$condition, levels=c("static","samemov", "diffmov"))
levels(df2$condition) <-  c("Static","Same movement", "Different movement")
levels(df2$sound_condition) <-  c("No sound","Sound")

#check for 3wayinteractions 
lmer2 <- lmer(sim_ratings ~  condition + step + sound_condition +
                condition*step + sound_condition*condition + step*sound_condition+
                step*sound_condition*condition+
                (1+condition|ID), 
              data = df2)
summary(lmer2)
lmer2_noint <- lmer(sim_ratings ~  condition + step + sound_condition +
                      condition*step + sound_condition*condition + step*sound_condition+ 
                      (1+condition|ID), 
                    data = df2)
summary(lmer2_noint)
anova(lmer2, lmer2_noint) #NO significant 3 ways interaction for the models - consider model without interaction LMER2
"            npar     AIC     BIC logLik deviance  Chisq Df Pr(>Chisq)
lmer2_noint   29 -577.24 -417.39 317.62  -635.24                     
lmer2         37 -565.86 -361.91 319.93  -639.86 4.6167  8     0.7976"

#check for2wayinteractions 
lmer2_noint2 <- lmer(sim_ratings ~  condition + step + sound_condition +
                       condition*step + step*sound_condition+
                      (1+condition|ID), 
                    data = df2)
summary(lmer2_noint2)
anova(lmer2_noint2, lmer2_noint)

# sound_condition*condition - SIGNIFICANT
'             npar     AIC     BIC logLik deviance  Chisq Df Pr(>Chisq)   
lmer2_noint2   27 -567.74 -418.91 310.87  -621.74                        
lmer2_noint    29 -577.24 -417.39 317.62  -635.24 13.503  2   0.001169 **'
# condition*step - no effect
'             npar     AIC     BIC logLik deviance  Chisq Df Pr(>Chisq)
lmer2_noint2   21 -586.20 -470.45 314.10  -628.20                     
lmer2_noint    29 -577.24 -417.39 317.62  -635.24 7.0395  8     0.5324'
# step*sound_condition - - no effect
'             npar     AIC     BIC logLik deviance  Chisq Df Pr(>Chisq)
lmer2_noint2   25 -583.91 -446.11 316.96  -633.91                     
lmer2_noint    29 -577.24 -417.39 317.62  -635.24 1.3295  4     0.8564'

#final model
lmer4 <- lmer(sim_ratings ~  condition + step + sound_condition +
                       sound_condition*condition+ 
                       (1 + condition|ID), 
                     data = df2)
summary(lmer4)
lmer4_plot<- plot_model(lmer4)
lmer4_plot
#plot the model without interaction with both factors
lmer4_plot<- plot_model(lmer4, type = "eff", terms = c("condition","sound_condition"), dot.size = 5, line.size = 0.5, alpha = 0.3) +
  theme_classic()+
  labs(x ="Motion condition",y="Normalised Similarity Ratings", title= "C)",color = "Sound condition")+
  theme(legend.position = "top", axis.text.x = element_text(angle  = 45, hjust = 1))+
  ylim(c(0,1))
lmer4_plot
ggsave('different_objects_motion and sound2.png', lmer4_plot, width = 6, height = 6, dpi = 300)
#posthoc values
post_learn = emmeans(lmer4, pairwise~sound_condition*condition, type = 'response', adjust = 'bonferroni')
results_learn <- post_learn$contrasts %>% rbind()
results_learn 
' contrast                                               estimate     SE     df t.ratio p.value
 No sound Static - Sound Static                          0.04791 0.0151 1640.0   3.181  0.0224 *
 No sound Static - No sound Same movement               -0.11814 0.0273   83.4  -4.327  0.0006 *
 No sound Static - Sound Same movement                  -0.11024 0.0273   83.4  -4.037  0.0018 *
 No sound Static - No sound Different movement           0.00301 0.0302   78.2   0.100  1.0000
 No sound Static - Sound Different movement             -0.02714 0.0302   78.2  -0.899  1.0000
 Sound Static - No sound Same movement                  -0.16605 0.0273   83.4  -6.081  <.0001 *
 Sound Static - Sound Same movement                     -0.15815 0.0273   83.4  -5.792  <.0001 *
 Sound Static - No sound Different movement             -0.04490 0.0302   78.2  -1.487  1.0000
 Sound Static - Sound Different movement                -0.07505 0.0302   78.2  -2.486  0.2256
 No sound Same movement - Sound Same movement            0.00790 0.0151 1640.0   0.525  1.0000
 No sound Same movement - No sound Different movement    0.12115 0.0243   91.7   4.985  <.0001 *
 No sound Same movement - Sound Different movement       0.09100 0.0243   91.7   3.744  0.0047 *
 Sound Same movement - No sound Different movement       0.11325 0.0243   91.7   4.660  0.0002 *
 Sound Same movement - Sound Different movement          0.08310 0.0243   91.7   3.419  0.0141 *
 No sound Different movement - Sound Different movement -0.03015 0.0151 1640.0  -2.002  0.6821'
# No_sound 
#         Static VS Same movement (p= 0.0006),
#         Same VS Different movement (p=0.0005)
# Sound 
#         Static VS Same movement (p=<.0001)
#         Same VS Different movement (p=0.0141)
# Static
#         No sound VS  Sound  (p=0.0224) 

results_CI_learn <- 
  confint(results_learn)
results_CI_learn

####REACTION TIMES - speed of response #####
#explore data with individual data points  - for raw data
gg3 <- ggplot(df, aes(x=step, y=rt_ms, fill = step, col = step))+
geom_jitter(size= 1, alpha = 0.3) +
  stat_summary(geom = 'point', size = 4, fun = 'median') +
 facet_wrap(~condition)
gg3
ggsave('rawdata_reactiontime_MOTION.png', gg3, width = 6, height = 6, dpi = 300)

#Remove outliers - exclusion criteria- RTs and cut off 
#a - GROUP cut_off - at least 3 SDs above the mean 
df_rt <- df
upper_cut_off <- mean(df_rt$rt_ms) + 2.5*(sd(df_rt$rt_ms))
lower_cut_off <- mean(df_rt$rt_ms) - 2.5*(sd(df_rt$rt_ms))
d_groupcutoff<- subset(df_rt, rt_ms < upper_cut_off & rt_ms > lower_cut_off)
df_rt$outlier_RT <- ifelse(df_rt$rt_ms > upper_cut_off |
                              df_rt$rt_ms < lower_cut_off, 'Yes', 'No')
table(df_rt$outlier_RT)
df_rt_noGroupoutliers <- subset(df_rt, outlier_RT == 'No')
#b - INDIVIDUAL cut-off - 4 SDs above the individual mean
df_rt_Indcutoff <- df_rt_noGroupoutliers %>% group_by(ID) %>%
  filter(rt_ms < mean(rt_ms) + (4 * sd(rt_ms)), rt_ms > mean(rt_ms) - (4 * sd(rt_ms)))
boxplot(df_rt_Indcutoff$rt_ms)
hist(df_rt_Indcutoff$rt_ms)
range(df_rt_Indcutoff$rt_ms)
#c - check people with RT below 500 ms 
d_below500 <- subset(df_rt_noGroupoutliers, rt_ms < 250) # 50 participant with RT fastest of 150 ms
summary(d_below500)

#final dataset -with no outliers
df_rt_noout <- subset(df_rt_noGroupoutliers, rt_ms > 250)
#compute means
df_rt_final <- df_rt_noout %>%
  group_by(ID, sdobj, condition, sound_condition ) %>%
  summarise(sim_ratings= mean(N_sim_ratings),
            rt_ms= mean(rt_ms))
df_rt_final$condition <- as.factor(df_rt_final$condition)
df_rt_final$condition <- factor(df_rt_final$condition, levels=c("static","samemov", "diffmov"))
levels(df_rt_final$condition) <-  c("Static","Same movement", "Different movement")
df_rt_final$sound_condition <- as.factor(df_rt_final$sound_condition)
levels(df_rt_final$sound_condition) <- c("No sound", "Sound")
df_rt_final <- merge(demog, df_rt_final, by ="ID")
df_rt_final$age_scaled <- scale(df_rt_final$age)
df_rt_final$sound_condition <- as.factor(df_rt_final$sound_condition)
df_rt_final$condition <- as.factor(df_rt_final$condition)

#check for the random slope
lmer1RT__withslope <- lmer(rt_ms ~ age_scaled + condition + sdobj + sound_condition +
                          condition*sdobj + sound_condition*sdobj + condition*sound_condition +
                         (1 + condition|ID), 
                        data = df_rt_final)
lmer1RT__noslope <- lmer(rt_ms ~ age_scaled +condition + sdobj + sound_condition +
                        condition*sdobj + sound_condition*sdobj + condition*sound_condition +
                        (1|ID), 
                      data = df_rt_final)
anova(lmer1RT__withslope, lmer1RT__noslope) #adding random slope does not improves model fit
'                   npar    AIC    BIC  logLik deviance Chisq Df Pr(>Chisq)    
lmer1RT__noslope     13 9828.4 9888.2 -4901.2   9802.4                        
lmer1RT__withslope   18 9597.4 9680.1 -4780.7   9561.4   241  5  < 2.2e-16 ***'

#run the model with the random slope included
#check 3way interaction
lmer1RT <- lmer(rt_ms ~ age_scaled + condition + sdobj + sound_condition +
                (1 + condition|ID), 
                data = df_rt_final)
summary(lmer1RT)
lmer1RT_noint <- lmer(rt_ms ~ age_scaled + sdobj + sound_condition +
                     (1 + condition|ID), 
                     data = df_rt_final)
summary(lmer1RT_noint)
anova(lmer1RT, lmer1RT_noint)

#3way interaction - none
#condition*sdobj  - no effect
'              npar    AIC    BIC  logLik deviance  Chisq Df Pr(>Chisq)
lmer1RT_noint   16 9595.0 9668.5 -4781.5   9563.0                     
lmer1RT         18 9597.4 9680.1 -4780.7   9561.4 1.5365  2     0.4638'
#sound_condition*sdobj- no effect
'              npar    AIC    BIC  logLik deviance  Chisq Df Pr(>Chisq)
lmer1RT_noint   17 9596.4 9674.5 -4781.2   9562.4                     
lmer1RT         18 9597.4 9680.1 -4780.7   9561.4 0.9597  1     0.3273'
#condition*sound_condition - no effect  (0.067)
'              npar    AIC    BIC  logLik deviance  Chisq Df Pr(>Chisq)  
lmer1RT_noint   16 9598.8 9672.3 -4783.4   9566.8                       
lmer1RT         18 9597.4 9680.1 -4780.7   9561.4 5.3961  2    0.06734 .'
#main effects - sound - no effect
'              npar    AIC    BIC  logLik deviance  Chisq Df Pr(>Chisq)
lmer1RT_noint   12 9593.3 9648.4 -4784.7   9569.3                     
lmer1RT         13 9595.3 9655.0 -4784.6   9569.3 0.0182  1     0.8927'
#main effects - sdobj - SIGNIFICANT
'              npar    AIC    BIC  logLik deviance  Chisq Df Pr(>Chisq)    
lmer1RT_noint   12 9604.4 9659.5 -4790.2   9580.4                         
lmer1RT         13 9595.3 9655.0 -4784.6   9569.3 11.062  1  0.0008813 ***'
#main effects - motion  - SIGNIFICANT
'              npar    AIC    BIC  logLik deviance  Chisq Df Pr(>Chisq)  
lmer1RT_noint   11 9599.7 9650.3 -4788.9   9577.7                       
lmer1RT         13 9595.3 9655.0 -4784.6   9569.3 8.4283  2    0.01479 *'

#FINAL MODEL
lmer1RT_final <- lmer(rt_ms ~ age_scaled + condition + sdobj +
                        (1 + condition|ID), 
                data = df_rt_final)
summary(lmer1RT_final)
#plot the model for single effects
lmer1RT_plot<- plot_model(lmer1RT_final, type = "eff", terms = c("condition","sdobj"), dot.size = 5, line.size = 0.5, alpha = 0.3) +
  theme_classic()+
  labs(x ="Motion conditions",y="Reaction times", title= "D)", color = "Object pairings")+
  theme(legend.title = element_text("Object pairings"), legend.position = "top",
        axis.text.x = element_text(angle  = 45, hjust = 1))+
ylim(c(750, 1500))
lmer1RT_plot
ggsave('RTs_model.png', lmer1RT_plot, width = 8, height = 8, dpi = 300)
#posthoc values
post_learn = emmeans(lmer1RT_final, pairwise~sdobj*condition, type = 'response', adjust = 'bonferroni')
results_learn <- post_learn$contrasts %>% rbind()
results_learn 
'Different Object static - Same Object static           29.14  8.73 547.1   3.340  0.0134*
 Different Object static - Different Object samemov     53.29 28.29  60.0   1.884  0.9662
 Different Object static - Same Object samemov          82.43 29.60  71.8   2.785  0.1025
 Different Object static - Different Object diffmov    -20.35 28.22  60.0  -0.721  1.0000
 Different Object static - Same Object diffmov           8.79 29.53  71.9   0.297  1.0000
 Same Object static - Different Object samemov          24.15 29.61  72.0   0.816  1.0000
 Same Object static - Same Object samemov               53.29 28.29  60.0   1.884  0.9662
 Same Object static - Different Object diffmov         -49.49 29.55  72.0  -1.675  1.0000
 Same Object static - Same Object diffmov              -20.35 28.22  60.0  -0.721  1.0000
 Different Object samemov - Same Object samemov         29.14  8.73 547.1   3.340  0.0134*
 Different Object samemov - Different Object diffmov   -73.65 25.30  60.0  -2.911  0.0756
 Different Object samemov - Same Object diffmov        -44.51 26.76  75.0  -1.663  1.0000
 Same Object samemov - Different Object diffmov       -102.79 26.76  75.0  -3.841  0.0038**
 Same Object samemov - Same Object diffmov             -73.65 25.30  60.0  -2.911  0.0756
 Different Object diffmov - Same Object diffmov         29.14  8.73 547.1   3.340  0.0134*'

# Static
#   Different Object VS Same Object (p=0.0134)
#Same movement
#   Different Object  VS Same Object (p=0.0134)
#Different movement
#   Different Object  VS Same Object (p=0.0134)
#
results_CI_learn <- 
  confint(results_learn)
results_CI_learn 

####paper figure###
plot_combined <- ggarrange(lmer_2waysign_plot,lmer3.finalmodel_plot,lmer4_plot,lmer1RT_plot, ncol =2, nrow=2)
plot_combined
ggsave('Figure4.jpg', plot_combined, width = 8, height = 8, dpi = 300)
