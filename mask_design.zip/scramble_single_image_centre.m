% def path
path = 'C:\Users\sevesom\OneDrive - Trinity College Dublin\Documents\Studies\Design\2- MOC - SM\mask generation\individual_masks\2.png';

%def tile size
tile_size = 12;

% read image in the path 
img = imread(path);

% show og image
imshow(img);

% showOption to true to see the process
showOption = true;

% scramble the center tiles
img_scrambled = hb_imageScramble(img, tile_size, showOption);

% def the size of the central area
center_size = [24,24]; % You can adjust this to your desired size

% etract the central area in the scrambled image
center_region = img_scrambled((end-center_size(1))/2+1:(end+center_size(1))/2, (end-center_size(2))/2+1:(end+center_size(2))/2, :);

% calculate the n of tiles in the central area
num_rows = floor(size(center_region, 1) / tile_size);
num_cols = floor(size(center_region, 2) / tile_size);
center_region = center_region(1:num_rows*tile_size, 1:num_cols*tile_size, :);

% reshape the central area 
tiles = mat2cell(center_region, ones(1, num_rows) * tile_size, ones(1, num_cols) * tile_size, size(center_region, 3));

% shuffle the tiles randomly
shuffled_tiles = tiles(randperm(numel(tiles)));

% reconstruct the central area with shuffled tiles
shuffled_center_region = cell2mat(reshape(shuffled_tiles, num_rows, num_cols));

% replace the central area  in the original scrambled image with the shuffled central area
img_scrambled((end-center_size(1))/2+1:(end+center_size(1))/2, (end-center_size(2))/2+1:(end+center_size(2))/2, :) = shuffled_center_region;

% show the final scrambled image 
imshow(img_scrambled);

% def output path
output_path = "C:\Users\sevesom\OneDrive - Trinity College Dublin\Documents\Studies\Design\2- MOC - SM\mask generation\individual_masks\individual masks_centered\";
% save the new scrambled image in the output
imwrite(img_scrambled, output_path + 'mask_2.png');
