
path = "C:\Users\sevesom\OneDrive - Trinity College Dublin\Documents\Studies\Design\2- MOC - SM\mask generation\individual_masks\36.png";

tile_size = 12;

img = imread(path);

imshow(img);

showOption = true;

img_scrambled = hb_imageScramble(img, tile_size, showOption);


output_path = "C:\Users\sevesom\OneDrive - Trinity College Dublin\Documents\Studies\Design\2- MOC - SM\mask generation\individual_masks\individual masks\";

imwrite(img_scrambled, output_path + 'mask_36.png');
